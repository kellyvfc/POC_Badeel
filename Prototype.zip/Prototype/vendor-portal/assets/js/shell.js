/**
 * Renders the persistent app shell: shellbar (maps to sap.tnt.ToolHeader) and
 * side navigation (maps to sap.tnt.SideNavigation). Called once per page with
 * the current page's nav key so the matching item is highlighted.
 */

const NAV_ITEMS = [
	{ key: "home", label: "Home", icon: "home", href: "index.html", roles: ["admin", "vendor"] },
	{ key: "inviteVendors", label: "Invite Vendors", icon: "user-plus", href: "invite-vendors.html", roles: ["admin"] },
	{ key: "vendors", label: "Vendors", icon: "users", href: "vendors.html", roles: ["admin"] },
	{ key: "qualification", label: "Qualification Profile", icon: "clipboard", href: "vendor-qualification.html", roles: ["vendor"] },
	{ key: "createInvoice", label: "Create Invoice", icon: "file-text", href: "create-invoice.html", roles: ["vendor"] },
	{ key: "invoices", label: "Invoices", icon: "dollar-sign", href: "invoices.html", roles: ["admin", "vendor"] }
];

function renderShellbar() {
	const role = getRole();
	const name = role === "admin" ? "Karim Haddad" : "Sofia Marín";
	return `
	<header class="shellbar">
		<button class="shellbar-menu-btn" id="navToggleBtn" title="Toggle navigation" aria-label="Toggle navigation">${icon("menu")}</button>
		<a class="shellbar-brand" href="index.html">
			${icon("shield", "shellbar-brand-icon")}
			<span class="shellbar-title">Badeel Vendor Portal</span>
		</a>
		<div class="shellbar-spacer"></div>
		<div class="shellbar-role-switch" id="roleSwitch">
			<button data-role="vendor" class="${role === "vendor" ? "active" : ""}">${icon("briefcase")}Vendor View</button>
			<button data-role="admin" class="${role === "admin" ? "active" : ""}">${icon("shield")}Admin View</button>
		</div>
		<button class="shellbar-icon-btn" id="bellBtn" title="Notifications" aria-label="Notifications">
			${icon("bell")}
			<span class="shellbar-badge">2</span>
		</button>
		<div class="shellbar-avatar" id="avatarBtn" title="${escapeHtml(name)}">${initials(name)}</div>
	</header>`;
}

function renderSideNav(activeKey) {
	const role = getRole();
	const items = NAV_ITEMS.filter(function (item) { return item.roles.indexOf(role) !== -1; });

	const itemsHtml = items.map(function (item) {
		const activeCls = item.key === activeKey ? " active" : "";
		return `<li><a class="side-nav-item${activeCls}" href="${item.href}">${icon(item.icon)}<span class="label">${item.label}</span></a></li>`;
	}).join("");

	return `
		<nav>
			<ul class="side-nav-list">${itemsHtml}</ul>
		</nav>
		<div class="side-nav-footer">
			<ul class="side-nav-list">
				<li><a class="side-nav-item" href="#" id="settingsLink">${icon("settings")}<span class="label">Settings</span></a></li>
				<li><a class="side-nav-item" href="#" id="logoutLink">${icon("log-out")}<span class="label">Log Out</span></a></li>
			</ul>
		</div>`;
}

function initShell(activeKey) {
	const shellbarRoot = document.getElementById("shellbar-root");
	const sidenavRoot = document.getElementById("sidenavRoot");

	if (shellbarRoot) {
		shellbarRoot.innerHTML = renderShellbar();
	}
	if (sidenavRoot) {
		sidenavRoot.innerHTML = renderSideNav(activeKey);
	}

	const appShell = document.getElementById("appShell");

	const navToggleBtn = document.getElementById("navToggleBtn");
	if (navToggleBtn) {
		navToggleBtn.addEventListener("click", function () {
			if (window.innerWidth <= 900) {
				appShell.classList.toggle("nav-open");
			} else {
				appShell.classList.toggle("nav-collapsed");
			}
		});
	}

	const roleSwitch = document.getElementById("roleSwitch");
	if (roleSwitch) {
		roleSwitch.querySelectorAll("button").forEach(function (btn) {
			btn.addEventListener("click", function () {
				const newRole = btn.getAttribute("data-role");
				if (newRole !== getRole()) {
					setRole(newRole);
					goTo("index.html");
				}
			});
		});
	}

	const bellBtn = document.getElementById("bellBtn");
	if (bellBtn) {
		bellBtn.addEventListener("click", function () {
			showToast("No new notifications.");
		});
	}

	["settingsLink", "logoutLink"].forEach(function (id) {
		const el = document.getElementById(id);
		if (el) {
			el.addEventListener("click", function (e) {
				e.preventDefault();
				showToast("This is a prototype action and is not wired up yet.");
			});
		}
	});
}
