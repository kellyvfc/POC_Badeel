/**
 * Client-side mock data for the prototype. In the Neptune/UI5 migration this
 * is replaced by server scripts / OData services (see NEPTUNE_MIGRATION.md) —
 * the shape of each record already mirrors a plausible OData entity.
 *
 * Business process (Completion Acceptance / CoC gate):
 *   Purchase Order --> Completion Request (vendor) --> Certificate of
 *   Completion (Badeel, issued only once a request is Accepted) -->
 *   Invoice (vendor, references exactly one approved, not-yet-invoiced CoC).
 *   A PO line item's RemainingQty only drops once an APPROVED CoC accepts it;
 *   a PO is fully accepted once every line item's RemainingQty reaches 0.
 */
const CURRENT_VENDOR_ID = "V1004";

const VENDORS = [
	{
		VendorId: "V1001",
		CompanyName: "Atlas Engineering Ltd.",
		ContactTitle: "Mr.",
		ContactFirstName: "John",
		ContactLastName: "Smith",
		Email: "john.smith@atlaseng.com",
		Phone: "+44 20 7946 0958",
		Country: "United Kingdom",
		Address: "14 Fenwick Road",
		City: "London",
		Zip: "EC2A 3QR",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-05-02",
		RegisteredOn: "2026-05-10",
		Categories: ["Power Plant Engineering Services", "Facility Maintenance"],
		ShipToLocations: [{ Name: "London HQ", Country: "United Kingdom", City: "London" }],
		TaxId: "GB123456789",
		BankVerified: true
	},
	{
		VendorId: "V1002",
		CompanyName: "Meridian Supply Chain Co.",
		ContactTitle: "Ms.",
		ContactFirstName: "Elena",
		ContactLastName: "Papadopoulos",
		Email: "elena.p@meridiansc.com",
		Phone: "+30 210 555 0134",
		Country: "Greece",
		Address: "22 Poseidonos Ave",
		City: "Athens",
		Zip: "17455",
		Status: "Registered",
		QualificationStatus: "In Review",
		InvitedOn: "2026-05-04",
		RegisteredOn: "2026-05-12",
		Categories: ["Logistics", "Spare Parts Warehousing"],
		ShipToLocations: [{ Name: "Piraeus Distribution Center", Country: "Greece", City: "Piraeus" }],
		TaxId: "EL094501783",
		BankVerified: false
	},
	{
		VendorId: "V1003",
		CompanyName: "NovaTech Digital Solutions",
		ContactTitle: "Mr.",
		ContactFirstName: "Rahul",
		ContactLastName: "Menon",
		Email: "rahul.menon@novatechds.com",
		Phone: "+971 4 555 0192",
		Country: "United Arab Emirates",
		Address: "Building 3, Dubai Internet City",
		City: "Dubai",
		Zip: "00000",
		Status: "Pending Registration",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-06-18",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1004",
		CompanyName: "Atlas Engineering Ltd.",
		ContactTitle: "Ms.",
		ContactFirstName: "Sofia",
		ContactLastName: "Marín",
		Email: "sofia.marin@atlaseng.com",
		Phone: "+34 91 555 0147",
		Country: "Spain",
		Address: "Calle Mayor 45",
		City: "Madrid",
		Zip: "28013",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-04-20",
		RegisteredOn: "2026-04-28",
		Categories: ["Power Plant Engineering Services", "Renewable Energy O&M"],
		ShipToLocations: [
			{ Name: "Madrid Solar Depot", Country: "Spain", City: "Madrid" },
			{ Name: "Seville Field Office", Country: "Spain", City: "Seville" }
		],
		TaxId: "ESB12345674",
		BankVerified: true
	},
	{
		VendorId: "V1005",
		CompanyName: "Horizon Facilities Group",
		ContactTitle: "Mr.",
		ContactFirstName: "Marcus",
		ContactLastName: "Weber",
		Email: "marcus.weber@horizonfg.de",
		Phone: "+49 89 555 0176",
		Country: "Germany",
		Address: "Königsallee 12",
		City: "Munich",
		Zip: "80331",
		Status: "Invitation Sent",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-07-01",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1006",
		CompanyName: "Pacific Legal Advisory",
		ContactTitle: "Mrs.",
		ContactFirstName: "Grace",
		ContactLastName: "Tan",
		Email: "grace.tan@pacificlegal.sg",
		Phone: "+65 6555 0128",
		Country: "Singapore",
		Address: "1 Raffles Place",
		City: "Singapore",
		Zip: "048616",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-03-14",
		RegisteredOn: "2026-03-20",
		Categories: ["Professional & Legal Services"],
		ShipToLocations: [{ Name: "Singapore Office", Country: "Singapore", City: "Singapore" }],
		TaxId: "SG198712345K",
		BankVerified: true
	},
	{
		VendorId: "V1007",
		CompanyName: "Bright Line IT Consulting",
		ContactTitle: "Mr.",
		ContactFirstName: "Daniel",
		ContactLastName: "Okafor",
		Email: "daniel.okafor@brightlineit.com",
		Phone: "+234 1 555 0163",
		Country: "Nigeria",
		Address: "12 Adeola Odeku St",
		City: "Lagos",
		Zip: "106104",
		Status: "Pending Registration",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-06-25",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1008",
		CompanyName: "Stellar Marine Logistics",
		ContactTitle: "Ms.",
		ContactFirstName: "Ines",
		ContactLastName: "Duarte",
		Email: "ines.duarte@stellarmarine.pt",
		Phone: "+351 21 555 0119",
		Country: "Portugal",
		Address: "Avenida da Liberdade 200",
		City: "Lisbon",
		Zip: "1250-147",
		Status: "Invitation Sent",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-07-05",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	}
];

const PURCHASE_ORDERS = [
	{
		PONumber: "PO-100234",
		VendorId: "V1004",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		Description: "Solar Panel Preventive Maintenance Services",
		Currency: "EUR",
		POValue: 174500,
		AdvancePaid: 30000,
		ContractRef: "CTR-4471",
		LineItems: [
			{ LineItemId: "PO-100234-L1", Description: "Q2 Preventive Maintenance - Solar Array A", OrderedQty: 1, UnitPrice: 65000, TaxPercent: 10 },
			{ LineItemId: "PO-100234-L2", Description: "Replacement Parts and Labor", OrderedQty: 1, UnitPrice: 26000, TaxPercent: 10 },
			{ LineItemId: "PO-100234-L3", Description: "Emergency Callout - Inverter Fault", OrderedQty: 1, UnitPrice: 18500, TaxPercent: 0 },
			{ LineItemId: "PO-100234-L4", Description: "Q3 Preventive Maintenance - Solar Array A", OrderedQty: 1, UnitPrice: 65000, TaxPercent: 10 }
		]
	},
	{
		PONumber: "PO-100251",
		VendorId: "V1004",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		Description: "Inverter Replacement - NREP Solar Cluster 3",
		Currency: "EUR",
		POValue: 84000,
		AdvancePaid: 0,
		ContractRef: "CTR-4502",
		LineItems: [
			{ LineItemId: "PO-100251-L1", Description: "Inverter Unit Replacement x2", OrderedQty: 2, UnitPrice: 32000, TaxPercent: 10 },
			{ LineItemId: "PO-100251-L2", Description: "Installation & Commissioning", OrderedQty: 1, UnitPrice: 20000, TaxPercent: 10 }
		]
	},
	{
		PONumber: "PO-100309",
		VendorId: "V1001",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		Description: "HVAC System Maintenance - Plant Administration Building",
		Currency: "GBP",
		POValue: 46800,
		AdvancePaid: 10000,
		ContractRef: "CTR-3390",
		LineItems: [
			{ LineItemId: "PO-100309-L1", Description: "HVAC Quarterly Service Contract - Q2", OrderedQty: 1, UnitPrice: 18500, TaxPercent: 8 },
			{ LineItemId: "PO-100309-L2", Description: "HVAC Filter Replacement Program", OrderedQty: 1, UnitPrice: 9800, TaxPercent: 0 },
			{ LineItemId: "PO-100309-L3", Description: "HVAC Quarterly Service Contract - Q3", OrderedQty: 1, UnitPrice: 18500, TaxPercent: 8 }
		]
	},
	{
		PONumber: "PO-100388",
		VendorId: "V1002",
		Entity: "SEPCO - Shuaiba Expansion Project Company",
		Description: "Spare Parts Warehousing & Logistics - RO Desalination Plant",
		Currency: "EUR",
		POValue: 34000,
		AdvancePaid: 0,
		ContractRef: "CTR-4610",
		LineItems: [
			{ LineItemId: "PO-100388-L1", Description: "Warehousing - July Allocation", OrderedQty: 1, UnitPrice: 30000, TaxPercent: 24 },
			{ LineItemId: "PO-100388-L2", Description: "Inbound Freight Handling", OrderedQty: 1, UnitPrice: 4000, TaxPercent: 20 }
		]
	},
	{
		PONumber: "PO-100412",
		VendorId: "V1006",
		Entity: "Badeel - Group Legal & Compliance",
		Description: "Advisory Retainer - Cross-border M&A",
		Currency: "USD",
		POValue: 30000,
		AdvancePaid: 15000,
		ContractRef: "CTR-2207",
		LineItems: [
			{ LineItemId: "PO-100412-L1", Description: "Legal Advisory Retainer - June", OrderedQty: 1, UnitPrice: 15000, TaxPercent: 0 },
			{ LineItemId: "PO-100412-L2", Description: "Legal Advisory Retainer - July", OrderedQty: 1, UnitPrice: 15000, TaxPercent: 0 }
		]
	},
	{
		PONumber: "PO-100455",
		VendorId: "V1001",
		Entity: "JWAP - Jubail Water and Power Company",
		Description: "Electrical Systems Audit - CCGT Facility",
		Currency: "GBP",
		POValue: 37500,
		AdvancePaid: 0,
		ContractRef: "CTR-3421",
		LineItems: [
			{ LineItemId: "PO-100455-L1", Description: "Electrical Systems Audit - Substation A", OrderedQty: 1, UnitPrice: 18000, TaxPercent: 0 },
			{ LineItemId: "PO-100455-L2", Description: "Electrical Systems Audit - Substation B", OrderedQty: 1, UnitPrice: 19500, TaxPercent: 0 }
		]
	}
];

const COMPLETION_REQUESTS = [
	{
		CompletionRequestId: "CR-1001",
		PONumber: "PO-100234",
		VendorId: "V1004",
		LineItems: [
			{ LineItemId: "PO-100234-L1", Description: "Q2 Preventive Maintenance - Solar Array A", OrderedQty: 1, CompletedQty: 1 },
			{ LineItemId: "PO-100234-L2", Description: "Replacement Parts and Labor", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Q2 maintenance completed on schedule, all checks passed.",
		Attachments: [{ FileName: "SolarArrayA_Q2_ServiceReport.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" }],
		Status: "Accepted",
		SubmittedOn: "2026-05-28",
		ReviewedOn: "2026-06-01",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2001"
	},
	{
		CompletionRequestId: "CR-1002",
		PONumber: "PO-100234",
		VendorId: "V1004",
		LineItems: [
			{ LineItemId: "PO-100234-L3", Description: "Emergency Callout - Inverter Fault", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Emergency inverter fault resolved same day.",
		Attachments: [{ FileName: "InverterFault_ServiceNote.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" }],
		Status: "Accepted",
		SubmittedOn: "2026-06-30",
		ReviewedOn: "2026-07-02",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2002"
	},
	{
		CompletionRequestId: "CR-1003",
		PONumber: "PO-100234",
		VendorId: "V1004",
		LineItems: [
			{ LineItemId: "PO-100234-L4", Description: "Q3 Preventive Maintenance - Solar Array A", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Q3 preventive maintenance completed, awaiting sign-off.",
		Attachments: [
			{ FileName: "SolarArrayA_Q3_ServiceReport.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" },
			{ FileName: "SiteVisit_Photos.zip", DocumentType: "Photos", UploadStatus: "Uploaded" }
		],
		Status: "Submitted",
		SubmittedOn: "2026-07-07",
		ReviewedOn: null,
		ReviewedBy: null,
		RejectionReason: null,
		CoCNumber: null
	},
	{
		CompletionRequestId: "CR-2001",
		PONumber: "PO-100251",
		VendorId: "V1004",
		LineItems: [
			{ LineItemId: "PO-100251-L1", Description: "Inverter Unit Replacement x2", OrderedQty: 2, CompletedQty: 2 }
		],
		Comments: "Both inverter units replaced and commissioned; system verified generating at rated capacity.",
		Attachments: [
			{ FileName: "Inverter_DeliveryNote.pdf", DocumentType: "Delivery Note", UploadStatus: "Uploaded" },
			{ FileName: "Commissioning_Photos.zip", DocumentType: "Photos", UploadStatus: "Uploaded" }
		],
		Status: "Accepted",
		SubmittedOn: "2026-07-01",
		ReviewedOn: "2026-07-04",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-3001"
	},
	{
		CompletionRequestId: "CR-1010",
		PONumber: "PO-100309",
		VendorId: "V1001",
		LineItems: [
			{ LineItemId: "PO-100309-L1", Description: "HVAC Quarterly Service Contract - Q2", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Q2 HVAC service completed.",
		Attachments: [{ FileName: "HVAC_Q2_ServiceRecord.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" }],
		Status: "Accepted",
		SubmittedOn: "2026-06-10",
		ReviewedOn: "2026-06-13",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2010"
	},
	{
		CompletionRequestId: "CR-1011",
		PONumber: "PO-100309",
		VendorId: "V1001",
		LineItems: [
			{ LineItemId: "PO-100309-L2", Description: "HVAC Filter Replacement Program", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Filter replacement program completed across all units.",
		Attachments: [{ FileName: "HVAC_FilterReplacement_Waybill.pdf", DocumentType: "Waybill", UploadStatus: "Uploaded" }],
		Status: "Accepted",
		SubmittedOn: "2026-05-05",
		ReviewedOn: "2026-05-08",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2011"
	},
	{
		CompletionRequestId: "CR-1016",
		PONumber: "PO-100309",
		VendorId: "V1001",
		LineItems: [
			{ LineItemId: "PO-100309-L3", Description: "HVAC Quarterly Service Contract - Q3", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Q3 HVAC service completed as scheduled.",
		Attachments: [{ FileName: "HVAC_Q3_ServiceRecord.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" }],
		Status: "Rejected",
		SubmittedOn: "2026-07-05",
		ReviewedOn: "2026-07-07",
		ReviewedBy: "Karim Haddad",
		RejectionReason: "Missing signed acceptance form from site supervisor.",
		CoCNumber: null
	},
	{
		CompletionRequestId: "CR-1012",
		PONumber: "PO-100412",
		VendorId: "V1006",
		LineItems: [
			{ LineItemId: "PO-100412-L1", Description: "Legal Advisory Retainer - June", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "June advisory services delivered per retainer scope.",
		Attachments: [{ FileName: "Legal_June_ServiceSummary.pdf", DocumentType: "Other", UploadStatus: "Uploaded" }],
		Status: "Accepted",
		SubmittedOn: "2026-06-18",
		ReviewedOn: "2026-06-19",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2012"
	},
	{
		CompletionRequestId: "CR-1013",
		PONumber: "PO-100388",
		VendorId: "V1002",
		LineItems: [
			{ LineItemId: "PO-100388-L1", Description: "Warehousing - July Allocation", OrderedQty: 1, CompletedQty: 1 },
			{ LineItemId: "PO-100388-L2", Description: "Inbound Freight Handling", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "July warehousing allocation and freight handling completed.",
		Attachments: [
			{ FileName: "Warehousing_DeliveryNote.pdf", DocumentType: "Delivery Note", UploadStatus: "Uploaded" },
			{ FileName: "Freight_Waybill.pdf", DocumentType: "Waybill", UploadStatus: "Uploaded" }
		],
		Status: "Accepted",
		SubmittedOn: "2026-06-25",
		ReviewedOn: "2026-06-27",
		ReviewedBy: "Karim Haddad",
		RejectionReason: null,
		CoCNumber: "CoC-2013"
	},
	{
		CompletionRequestId: "CR-1014",
		PONumber: "PO-100455",
		VendorId: "V1001",
		LineItems: [
			{ LineItemId: "PO-100455-L1", Description: "Electrical Systems Audit - Substation A", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "",
		Attachments: [],
		Status: "Draft",
		SubmittedOn: null,
		ReviewedOn: null,
		ReviewedBy: null,
		RejectionReason: null,
		CoCNumber: null
	},
	{
		CompletionRequestId: "CR-1015",
		PONumber: "PO-100455",
		VendorId: "V1001",
		LineItems: [
			{ LineItemId: "PO-100455-L2", Description: "Electrical Systems Audit - Substation B", OrderedQty: 1, CompletedQty: 1 }
		],
		Comments: "Substation B audit completed, report attached.",
		Attachments: [{ FileName: "SubstationB_AuditReport.pdf", DocumentType: "Service Completion Record", UploadStatus: "Uploaded" }],
		Status: "Under Review",
		SubmittedOn: "2026-07-06",
		ReviewedOn: null,
		ReviewedBy: null,
		RejectionReason: null,
		CoCNumber: null
	}
];

const CERTIFICATES_OF_COMPLETION = [
	{
		CoCNumber: "CoC-2001",
		PONumber: "PO-100234",
		VendorId: "V1004",
		IssueDate: "2026-06-01",
		Status: "Approved",
		CompletionRequestId: "CR-1001",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100234-L1", Description: "Q2 Preventive Maintenance - Solar Array A", AcceptedQty: 1, UnitPrice: 65000, TaxPercent: 10 },
			{ LineItemId: "PO-100234-L2", Description: "Replacement Parts and Labor", AcceptedQty: 1, UnitPrice: 26000, TaxPercent: 10 }
		]
	},
	{
		CoCNumber: "CoC-2002",
		PONumber: "PO-100234",
		VendorId: "V1004",
		IssueDate: "2026-07-02",
		Status: "Approved",
		CompletionRequestId: "CR-1002",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100234-L3", Description: "Emergency Callout - Inverter Fault", AcceptedQty: 1, UnitPrice: 18500, TaxPercent: 0 }
		]
	},
	{
		CoCNumber: "CoC-3001",
		PONumber: "PO-100251",
		VendorId: "V1004",
		IssueDate: "2026-07-04",
		Status: "Approved",
		CompletionRequestId: "CR-2001",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100251-L1", Description: "Inverter Unit Replacement x2", AcceptedQty: 2, UnitPrice: 32000, TaxPercent: 10 }
		]
	},
	{
		CoCNumber: "CoC-2010",
		PONumber: "PO-100309",
		VendorId: "V1001",
		IssueDate: "2026-06-13",
		Status: "Approved",
		CompletionRequestId: "CR-1010",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100309-L1", Description: "HVAC Quarterly Service Contract - Q2", AcceptedQty: 1, UnitPrice: 18500, TaxPercent: 8 }
		]
	},
	{
		CoCNumber: "CoC-2011",
		PONumber: "PO-100309",
		VendorId: "V1001",
		IssueDate: "2026-05-08",
		Status: "Approved",
		CompletionRequestId: "CR-1011",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100309-L2", Description: "HVAC Filter Replacement Program", AcceptedQty: 1, UnitPrice: 9800, TaxPercent: 0 }
		]
	},
	{
		CoCNumber: "CoC-2012",
		PONumber: "PO-100412",
		VendorId: "V1006",
		IssueDate: "2026-06-19",
		Status: "Approved",
		CompletionRequestId: "CR-1012",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100412-L1", Description: "Legal Advisory Retainer - June", AcceptedQty: 1, UnitPrice: 15000, TaxPercent: 0 }
		]
	},
	{
		CoCNumber: "CoC-2013",
		PONumber: "PO-100388",
		VendorId: "V1002",
		IssueDate: "2026-06-27",
		Status: "Approved",
		CompletionRequestId: "CR-1013",
		ApprovedBy: "Karim Haddad",
		LineItems: [
			{ LineItemId: "PO-100388-L1", Description: "Warehousing - July Allocation", AcceptedQty: 1, UnitPrice: 30000, TaxPercent: 24 },
			{ LineItemId: "PO-100388-L2", Description: "Inbound Freight Handling", AcceptedQty: 1, UnitPrice: 4000, TaxPercent: 20 }
		]
	}
];

const INVOICES = [
	{
		InvoiceId: "INV-2026-0041",
		PONumber: "PO-100234",
		CoCNumber: "CoC-2001",
		VendorId: "V1004",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		InvoiceDate: "2026-06-02",
		DueDate: "2026-07-02",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		AdvanceAmount: 30000,
		Status: "Approved",
		SubmittedOn: "2026-06-02",
		LineItems: [
			{ Description: "Q2 Preventive Maintenance - Solar Array A", Quantity: 1, UnitPrice: 65000, TaxPercent: 10 },
			{ Description: "Replacement Parts and Labor", Quantity: 1, UnitPrice: 26000, TaxPercent: 10 }
		],
		Attachments: [
			{ FileName: "Atlas_Tax_Invoice_0041.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }
		]
	},
	{
		InvoiceId: "INV-2026-0052",
		PONumber: "PO-100309",
		CoCNumber: "CoC-2010",
		VendorId: "V1001",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		InvoiceDate: "2026-06-15",
		DueDate: "2026-07-15",
		Currency: "GBP",
		PaymentTerms: "Net 30",
		AdvanceAmount: 5000,
		Status: "Under Review",
		SubmittedOn: "2026-06-15",
		LineItems: [{ Description: "HVAC Quarterly Service Contract - Q2", Quantity: 1, UnitPrice: 18500, TaxPercent: 8 }],
		Attachments: [{ FileName: "HVAC_Invoice_0052.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0058",
		PONumber: "PO-100412",
		CoCNumber: "CoC-2012",
		VendorId: "V1006",
		VendorName: "Pacific Legal Advisory",
		Entity: "Badeel - Group Legal & Compliance",
		InvoiceDate: "2026-06-20",
		DueDate: "2026-07-20",
		Currency: "USD",
		PaymentTerms: "Net 45",
		AdvanceAmount: 0,
		Status: "Submitted",
		SubmittedOn: "2026-06-20",
		LineItems: [{ Description: "Legal Advisory Retainer - June", Quantity: 1, UnitPrice: 15000, TaxPercent: 0 }],
		Attachments: [{ FileName: "Pacific_Legal_Invoice_June.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0063",
		PONumber: "PO-100388",
		CoCNumber: "CoC-2013",
		VendorId: "V1002",
		VendorName: "Meridian Supply Chain Co.",
		Entity: "SEPCO - Shuaiba Expansion Project Company",
		InvoiceDate: "2026-06-28",
		DueDate: "2026-07-28",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		AdvanceAmount: 0,
		Status: "Rejected",
		SubmittedOn: "2026-06-28",
		RejectionReason: "Missing signed delivery note for line item 2.",
		LineItems: [
			{ Description: "Warehousing - July Allocation", Quantity: 1, UnitPrice: 30000, TaxPercent: 24 },
			{ Description: "Inbound Freight Handling", Quantity: 1, UnitPrice: 4000, TaxPercent: 20 }
		],
		Attachments: [{ FileName: "Meridian_Invoice_0063.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0071",
		PONumber: "PO-100234",
		CoCNumber: "CoC-2002",
		VendorId: "V1004",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		InvoiceDate: "2026-07-03",
		DueDate: "2026-08-02",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		AdvanceAmount: 0,
		Status: "Draft",
		SubmittedOn: null,
		LineItems: [{ Description: "Emergency Callout - Inverter Fault", Quantity: 1, UnitPrice: 18500, TaxPercent: 0 }],
		Attachments: []
	},
	{
		InvoiceId: "INV-2026-0028",
		PONumber: "PO-100309",
		CoCNumber: "CoC-2011",
		VendorId: "V1001",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		InvoiceDate: "2026-05-10",
		DueDate: "2026-06-09",
		Currency: "GBP",
		PaymentTerms: "Net 30",
		AdvanceAmount: 0,
		Status: "Paid",
		SubmittedOn: "2026-05-10",
		PaidOn: "2026-06-08",
		PaymentReference: "TRF-6620-GB",
		LineItems: [{ Description: "HVAC Filter Replacement Program", Quantity: 1, UnitPrice: 9800, TaxPercent: 0 }],
		Attachments: [{ FileName: "HVAC_Invoice_0028.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	}
];

// ---------------------------------------------------------------------------
// Lookups
// ---------------------------------------------------------------------------

function findVendor(vendorId) {
	return VENDORS.find(function (v) { return v.VendorId === vendorId; });
}

function findInvoice(invoiceId) {
	return INVOICES.find(function (i) { return i.InvoiceId === invoiceId; });
}

function findPO(poNumber) {
	return PURCHASE_ORDERS.find(function (p) { return p.PONumber === poNumber; });
}

function findCompletionRequest(id) {
	return COMPLETION_REQUESTS.find(function (r) { return r.CompletionRequestId === id; });
}

function findCoC(coCNumber) {
	return CERTIFICATES_OF_COMPLETION.find(function (c) { return c.CoCNumber === coCNumber; });
}

// ---------------------------------------------------------------------------
// Amount helpers
// ---------------------------------------------------------------------------

function lineItemTotal(item) {
	const net = item.Quantity * item.UnitPrice;
	return net + net * (item.TaxPercent / 100);
}

function invoiceGrossFromLineItems(lineItems) {
	return lineItems.reduce(function (sum, item) { return sum + lineItemTotal(item); }, 0);
}

function invoiceNetPayable(invoice) {
	return invoiceGrossFromLineItems(invoice.LineItems) - (invoice.AdvanceAmount || 0);
}

function coCLineItemTotal(item) {
	const net = item.AcceptedQty * item.UnitPrice;
	return net + net * (item.TaxPercent / 100);
}

function coCAcceptedAmount(coc) {
	return coc.LineItems.reduce(function (sum, item) { return sum + coCLineItemTotal(item); }, 0);
}

/** Converts a CoC's accepted line items into invoice line item shape (Quantity instead of AcceptedQty). */
function coCLineItemsToInvoiceLineItems(coc) {
	return coc.LineItems.map(function (item) {
		return { Description: item.Description, Quantity: item.AcceptedQty, UnitPrice: item.UnitPrice, TaxPercent: item.TaxPercent };
	});
}

// ---------------------------------------------------------------------------
// Completion Request / CoC / PO relationship helpers
// ---------------------------------------------------------------------------

function getCompletionRequestsForPO(poNumber) {
	return COMPLETION_REQUESTS.filter(function (r) { return r.PONumber === poNumber; });
}

function getCompletionRequestsForVendor(vendorId) {
	return COMPLETION_REQUESTS.filter(function (r) { return r.VendorId === vendorId; });
}

function getCoCsForPO(poNumber) {
	return CERTIFICATES_OF_COMPLETION.filter(function (c) { return c.PONumber === poNumber; });
}

function getCoCsForVendor(vendorId) {
	return CERTIFICATES_OF_COMPLETION.filter(function (c) { return c.VendorId === vendorId; });
}

function getApprovedCoCsForPO(poNumber) {
	return getCoCsForPO(poNumber).filter(function (c) { return c.Status === "Approved"; });
}

function getInvoiceForCoC(coCNumber) {
	return INVOICES.find(function (i) { return i.CoCNumber === coCNumber; });
}

/** Approved CoCs for a PO that have not yet been used on any invoice — these are what Create Invoice may pick from. */
function getInvoiceableCoCsForPO(poNumber) {
	return getApprovedCoCsForPO(poNumber).filter(function (c) { return !getInvoiceForCoC(c.CoCNumber); });
}

/** Every PO that currently has at least one invoiceable (approved, unused) CoC. */
function getPOsWithInvoiceableCoCs(vendorId) {
	return PURCHASE_ORDERS.filter(function (po) {
		return po.VendorId === vendorId && getInvoiceableCoCsForPO(po.PONumber).length > 0;
	});
}

/** Sum of AcceptedQty across all APPROVED CoCs for a given PO line item. */
function getAcceptedQtyForLineItem(poNumber, lineItemId) {
	return getApprovedCoCsForPO(poNumber).reduce(function (sum, coc) {
		const match = coc.LineItems.find(function (li) { return li.LineItemId === lineItemId; });
		return sum + (match ? match.AcceptedQty : 0);
	}, 0);
}

/** Ordered / Accepted / Remaining rollup for every line item of a PO. */
function getPOLineItemProgress(poNumber) {
	const po = findPO(poNumber);
	if (!po) { return []; }
	return po.LineItems.map(function (li) {
		const acceptedQty = getAcceptedQtyForLineItem(poNumber, li.LineItemId);
		return {
			LineItemId: li.LineItemId,
			Description: li.Description,
			OrderedQty: li.OrderedQty,
			UnitPrice: li.UnitPrice,
			TaxPercent: li.TaxPercent,
			AcceptedQty: acceptedQty,
			RemainingQty: Math.max(0, li.OrderedQty - acceptedQty)
		};
	});
}

function isPOFullyAccepted(poNumber) {
	return getPOLineItemProgress(poNumber).every(function (li) { return li.RemainingQty <= 0; });
}

function getInvoicesForPO(poNumber) {
	return INVOICES.filter(function (i) { return i.PONumber === poNumber; });
}

/** Advance paid on the PO minus whatever has already been drawn down by other invoices. */
function getRemainingAdvanceForPO(poNumber) {
	const po = findPO(poNumber);
	if (!po) { return 0; }
	const alreadyApplied = getInvoicesForPO(poNumber).reduce(function (sum, inv) { return sum + (inv.AdvanceAmount || 0); }, 0);
	return Math.max(0, po.AdvancePaid - alreadyApplied);
}

function getInvoicesForVendor(vendorId) {
	return INVOICES.filter(function (i) { return i.VendorId === vendorId; });
}
