(function () {
	const role = getRole();
	const TODAY = "2026-07-08";
	let activeStatus = "All";
	let searchTerm = "";

	if (role === "admin") {
		document.getElementById("pageSubtitle").textContent = "Track payment progress for approved invoices across all vendors.";
		document.getElementById("paymentsTableHead").innerHTML = `<tr><th>Invoice</th><th>Vendor</th><th>PO Number</th><th class="num">Amount Payable</th><th>Due Date</th><th>Payment Status</th><th>Paid On</th></tr>`;
	} else {
		document.getElementById("paymentsTableHead").innerHTML = `<tr><th>Invoice</th><th>PO Number</th><th class="num">Amount Payable</th><th>Due Date</th><th>Payment Status</th><th>Paid On</th></tr>`;
	}

	function paymentStatusFor(inv) {
		if (inv.Status === "Paid") { return "Paid"; }
		if (inv.Status === "Approved" && inv.DueDate < TODAY) { return "Overdue"; }
		return "Awaiting Payment";
	}

	function baseList() {
		const scoped = role === "admin" ? INVOICES : getInvoicesForVendor(CURRENT_VENDOR_ID);
		return scoped.filter(function (inv) { return inv.Status === "Approved" || inv.Status === "Paid"; });
	}

	function render() {
		const filtered = baseList().filter(function (inv) {
			const payStatus = paymentStatusFor(inv);
			const matchesStatus = activeStatus === "All" || payStatus === activeStatus;
			const haystack = (inv.InvoiceId + " " + inv.PONumber).toLowerCase();
			const matchesSearch = haystack.indexOf(searchTerm.toLowerCase()) !== -1;
			return matchesStatus && matchesSearch;
		}).sort(function (a, b) { return a.DueDate.localeCompare(b.DueDate); });

		const rows = filtered.map(function (inv) {
			const vendorCell = role === "admin" ? `<td>${escapeHtml(inv.VendorName)}</td>` : "";
			return `<tr class="row-nav" onclick="goTo('invoice-detail.html?invoiceId=${inv.InvoiceId}')">
				<td><span class="object-identifier-title">${inv.InvoiceId}</span></td>
				${vendorCell}
				<td>${inv.PONumber}</td>
				<td class="num">${formatCurrency(invoiceNetPayable(inv), inv.Currency)}</td>
				<td>${formatDate(inv.DueDate)}</td>
				<td>${objectStatusHtml(paymentStatusFor(inv))}</td>
				<td>${inv.PaidOn ? formatDate(inv.PaidOn) : "–"}</td>
			</tr>`;
		}).join("");

		const colspan = role === "admin" ? 7 : 6;
		document.querySelector("#paymentsTable tbody").innerHTML = rows ||
			`<tr><td colspan="${colspan}"><div class="empty-state">${icon("search")}<div>No approved or paid invoices match your filters.</div></div></td></tr>`;

		document.getElementById("resultCount").textContent = filtered.length + " of " + baseList().length + " invoices";
	}

	document.getElementById("searchInput").addEventListener("input", function (e) {
		searchTerm = e.target.value;
		render();
	});

	document.getElementById("statusChips").addEventListener("click", function (e) {
		const btn = e.target.closest(".chip");
		if (!btn) { return; }
		document.querySelectorAll("#statusChips .chip").forEach(function (c) { c.classList.remove("active"); });
		btn.classList.add("active");
		activeStatus = btn.dataset.status;
		render();
	});

	render();
})();
