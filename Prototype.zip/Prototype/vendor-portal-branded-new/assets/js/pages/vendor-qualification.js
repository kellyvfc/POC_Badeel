(function () {
	const vendor = findVendor(CURRENT_VENDOR_ID);
	const banks = [];
	const docs = [];

	document.getElementById("qualificationStatusBadge").innerHTML = objectStatusHtml(vendor.QualificationStatus);

	document.getElementById("cpName").value = vendor.CompanyName || "";
	document.getElementById("cpCountry").value = vendor.Country || "";
	document.getElementById("cpAddress").value = vendor.Address || "";
	document.getElementById("cpCity").value = vendor.City || "";
	document.getElementById("cpContactFirstName").value = vendor.ContactFirstName || "";
	document.getElementById("cpContactLastName").value = vendor.ContactLastName || "";
	document.getElementById("cpEmail").value = vendor.Email || "";
	document.getElementById("cpPhone").value = vendor.Phone || "";
	document.getElementById("taxId").value = vendor.TaxId || "";

	function validateCompanyProfile() {
		const required = ["cpName", "cpCountry", "cpAddress", "cpCity", "cpContactFirstName", "cpContactLastName"];
		const invalid = required.filter(function (id) { return !document.getElementById(id).value.trim(); });
		invalid.forEach(function (id) { showToast("Please complete the required company profile fields."); });
		return invalid.length === 0;
	}

	function persistCompanyProfile() {
		vendor.CompanyName = document.getElementById("cpName").value.trim();
		vendor.Country = document.getElementById("cpCountry").value;
		vendor.Address = document.getElementById("cpAddress").value.trim();
		vendor.City = document.getElementById("cpCity").value.trim();
		vendor.ContactFirstName = document.getElementById("cpContactFirstName").value.trim();
		vendor.ContactLastName = document.getElementById("cpContactLastName").value.trim();
		vendor.Email = document.getElementById("cpEmail").value.trim();
		vendor.Phone = document.getElementById("cpPhone").value.trim();
	}

	function renderBanks() {
		document.querySelector("#bankTable tbody").innerHTML = banks.length
			? banks.map(function (b, idx) {
				return `<tr>
					<td>${escapeHtml(b.name)}</td>
					<td>${escapeHtml(b.account)}</td>
					<td>${escapeHtml(b.swift) || "–"}</td>
					<td>${escapeHtml(b.currency)}</td>
					<td><button class="icon-btn remove-bank-btn" data-idx="${idx}" title="Remove">${icon("trash")}</button></td>
				</tr>`;
			}).join("")
			: `<tr><td colspan="5" class="text-secondary">No bank details added yet.</td></tr>`;

		document.querySelectorAll(".remove-bank-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				banks.splice(Number(btn.dataset.idx), 1);
				renderBanks();
			});
		});
	}

	function renderDocs() {
		document.getElementById("qualDocsList").innerHTML = docs.map(function (d, idx) {
			return `<li class="upload-list-item">
				<div class="upload-list-item-icon">${icon("file-text")}</div>
				<div class="upload-list-item-info">
					<div class="upload-list-item-name">${escapeHtml(d.name)}</div>
					<div class="upload-list-item-meta">${objectStatusHtml("Uploaded")}</div>
				</div>
				<button class="icon-btn remove-doc-btn" data-idx="${idx}" title="Remove">${icon("trash")}</button>
			</li>`;
		}).join("");

		document.querySelectorAll(".remove-doc-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				docs.splice(Number(btn.dataset.idx), 1);
				renderDocs();
			});
		});
	}

	document.getElementById("addBankBtn").addEventListener("click", function () {
		document.getElementById("bankName").value = "";
		document.getElementById("bankAccount").value = "";
		document.getElementById("bankSwift").value = "";
		openDialog("bankDialog");
	});

	document.getElementById("saveBankBtn").addEventListener("click", function () {
		const name = document.getElementById("bankName").value.trim();
		const account = document.getElementById("bankAccount").value.trim();
		if (!name || !account) {
			showToast("Bank name and account number are required.");
			return;
		}
		banks.push({
			name: name,
			account: account,
			swift: document.getElementById("bankSwift").value.trim(),
			currency: document.getElementById("bankCurrency").value
		});
		renderBanks();
		closeDialog("bankDialog");
		showToast("Bank details added.");
	});

	document.getElementById("qualUploadBtn").addEventListener("click", function () {
		document.getElementById("qualFileInput").click();
	});

	document.getElementById("qualFileInput").addEventListener("change", function (e) {
		Array.from(e.target.files).forEach(function (f) {
			docs.push({ name: f.name });
		});
		renderDocs();
		e.target.value = "";
	});

	document.getElementById("saveDraftBtn").addEventListener("click", function () {
		persistCompanyProfile();
		showToast("Qualification profile saved as draft.");
	});

	document.getElementById("submitQualBtn").addEventListener("click", function () {
		if (!validateCompanyProfile()) {
			return;
		}
		if (!document.getElementById("taxId").value.trim()) {
			showToast("Please provide a Tax / VAT ID before submitting.");
			return;
		}
		if (banks.length === 0) {
			showToast("Please add at least one bank detail before submitting.");
			return;
		}
		persistCompanyProfile();
		vendor.QualificationStatus = "In Review";
		document.getElementById("qualificationStatusBadge").innerHTML = objectStatusHtml(vendor.QualificationStatus);
		showToast("Qualification profile submitted for review.");
	});

	if (vendor.BankVerified) {
		banks.push({ name: "Banco Santander", account: "ES91 2100 0418 4502 0005 1332", swift: "BSCHESMM", currency: "EUR" });
	}

	renderBanks();
	renderDocs();
})();
