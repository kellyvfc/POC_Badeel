(function () {
	const role = getRole();
	let searchTerm = "";

	if (role === "admin") {
		document.getElementById("pageSubtitle").textContent = "Certificates of Completion issued across all vendors. Only approved CoCs may be used to create an invoice.";
		document.getElementById("cocTableHead").innerHTML = `<tr><th>CoC Number</th><th>Vendor</th><th>Purchase Order</th><th>Issue Date</th><th>Status</th><th class="num">Accepted Qty</th><th class="num">Accepted Amount</th></tr>`;
	} else {
		document.getElementById("cocTableHead").innerHTML = `<tr><th>CoC Number</th><th>Purchase Order</th><th>Issue Date</th><th>Status</th><th class="num">Accepted Qty</th><th class="num">Accepted Amount</th></tr>`;
	}

	function baseList() {
		return role === "admin" ? CERTIFICATES_OF_COMPLETION : getCoCsForVendor(CURRENT_VENDOR_ID);
	}

	function render() {
		const filtered = baseList().filter(function (c) {
			const haystack = (c.CoCNumber + " " + c.PONumber).toLowerCase();
			return haystack.indexOf(searchTerm.toLowerCase()) !== -1;
		}).sort(function (a, b) { return b.IssueDate.localeCompare(a.IssueDate); });

		const rows = filtered.map(function (c) {
			const po = findPO(c.PONumber);
			const vendor = findVendor(c.VendorId);
			const vendorCell = role === "admin" ? `<td>${escapeHtml(vendor ? vendor.CompanyName : c.VendorId)}</td>` : "";
			const acceptedQty = c.LineItems.reduce(function (sum, li) { return sum + li.AcceptedQty; }, 0);
			return `<tr class="row-nav" onclick="goTo('coc-detail.html?coCNumber=${c.CoCNumber}')">
				<td><span class="object-identifier-title">${c.CoCNumber}</span></td>
				${vendorCell}
				<td>${c.PONumber}</td>
				<td>${formatDate(c.IssueDate)}</td>
				<td>${objectStatusHtml(c.Status)}</td>
				<td class="num">${acceptedQty}</td>
				<td class="num">${formatCurrency(coCAcceptedAmount(c), po ? po.Currency : "EUR")}</td>
			</tr>`;
		}).join("");

		const colspan = role === "admin" ? 7 : 6;
		document.querySelector("#cocTable tbody").innerHTML = rows ||
			`<tr><td colspan="${colspan}"><div class="empty-state">${icon("search")}<div>No certificates of completion match your search.</div></div></td></tr>`;

		document.getElementById("resultCount").textContent = filtered.length + " of " + baseList().length + " certificates";
	}

	document.getElementById("searchInput").addEventListener("input", function (e) {
		searchTerm = e.target.value;
		render();
	});

	render();
})();
