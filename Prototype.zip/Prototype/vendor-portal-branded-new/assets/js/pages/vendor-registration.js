(function () {
	document.getElementById("regEmail").value = qs("email") || "sofia.marin@atlaseng.com";

	const categories = [];
	let locationCount = 0;

	function renderCategories() {
		document.getElementById("categoryTags").innerHTML = categories.map(function (c, idx) {
			return `<span class="tag">${escapeHtml(c)}<button data-idx="${idx}" class="remove-category-btn">${icon("x")}</button></span>`;
		}).join("") || `<span class="text-secondary" style="font-size:0.8rem;">No categories added yet.</span>`;

		document.querySelectorAll(".remove-category-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				categories.splice(Number(btn.dataset.idx), 1);
				renderCategories();
			});
		});
	}

	document.getElementById("addCategoryBtn").addEventListener("click", function () {
		const input = document.getElementById("newCategoryInput");
		const value = input.value.trim();
		if (value) {
			categories.push(value);
			input.value = "";
			renderCategories();
		}
	});

	function addLocationRow() {
		locationCount += 1;
		const row = document.createElement("div");
		row.className = "repeatable-row";
		row.innerHTML = `
			<div class="form-field">
				<label class="form-label">Location Name</label>
				<input type="text" class="loc-name" placeholder="e.g. Madrid Solar Depot">
			</div>
			<div class="form-field">
				<label class="form-label">City</label>
				<input type="text" class="loc-city">
			</div>
			<div class="form-field">
				<label class="form-label">Country</label>
				<input type="text" class="loc-country">
			</div>
			<button class="icon-btn remove-location-btn" type="button" title="Remove location">${icon("trash")}</button>
		`;
		row.querySelector(".remove-location-btn").addEventListener("click", function () {
			row.remove();
		});
		document.getElementById("locationRows").appendChild(row);
	}

	document.getElementById("addLocationBtn").addEventListener("click", addLocationRow);

	function required(id) {
		const field = document.getElementById(id);
		const valid = field.value.trim().length > 0;
		field.closest(".form-field").classList.toggle("has-error", !valid);
		return valid;
	}

	document.getElementById("registerBtn").addEventListener("click", function () {
		const validations = [
			required("companyName"),
			required("country"),
			required("city"),
			required("address"),
			required("contactFirstName"),
			required("contactLastName")
		];

		if (validations.indexOf(false) !== -1) {
			showToast("Please complete all required fields.");
			return;
		}

		goTo("registration-confirmation.html");
	});

	renderCategories();
})();
