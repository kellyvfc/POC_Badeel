(function () {
	const STEP_LABELS = ["Select PO", "Select CoC", "Invoice Details", "Attachments", "Advance Payment", "Review & Submit"];
	let currentStep = 1;
	let selectedPO = null;
	let selectedCoC = null;
	let attachments = [];
	let nextInvoiceSeq = 100;

	const eligiblePOs = getPOsWithInvoiceableCoCs(CURRENT_VENDOR_ID);

	function renderProgress() {
		let html = "";
		STEP_LABELS.forEach(function (label, idx) {
			const stepNum = idx + 1;
			const state = stepNum < currentStep ? "done" : (stepNum === currentStep ? "active" : "");
			html += `<div class="wizard-step-indicator ${state}">
				<div class="step-circle">${stepNum < currentStep ? icon("check-circle") : stepNum}</div>
				<div class="step-label">${label}</div>
			</div>`;
			if (stepNum < STEP_LABELS.length) {
				html += `<div class="wizard-connector ${stepNum < currentStep ? "done" : ""}"></div>`;
			}
		});
		document.getElementById("wizardProgress").innerHTML = html;
	}

	function showStep(step) {
		document.querySelectorAll(".wizard-panel").forEach(function (panel) {
			panel.classList.toggle("active", panel.dataset.step === String(step));
		});
		document.getElementById("wizardNav").style.display = step === "done" ? "none" : "flex";
		document.getElementById("wizardBackBtn").style.visibility = (step === 1) ? "hidden" : "visible";
		document.getElementById("wizardNextBtn").textContent = (step === 6) ? "Submit Invoice" : "Next";
		if (typeof step === "number") {
			renderProgress();
		}
		window.scrollTo({ top: 0, behavior: "smooth" });
	}

	// ---------- Step 1: Select PO ----------
	function renderPOTable() {
		if (eligiblePOs.length === 0) {
			document.getElementById("noEligiblePOsState").innerHTML = `
				<div class="empty-state">
					${icon("shield")}
					<div>You have no purchase orders with an approved, uninvoiced Certificate of Completion right now.</div>
					<div class="text-secondary" style="margin-top:4px;">Submit a <a href="create-completion-request.html">Completion Request</a> once work is finished — Badeel will review it and issue a CoC before you can invoice.</div>
				</div>`;
			document.getElementById("wizardNextBtn").disabled = true;
			return;
		}

		document.querySelector("#poTable tbody").innerHTML = eligiblePOs.map(function (po) {
			const invoiceableCoCs = getInvoiceableCoCsForPO(po.PONumber);
			const invoiceableAmount = invoiceableCoCs.reduce(function (sum, c) { return sum + coCAcceptedAmount(c); }, 0);
			return `<tr class="row-nav" data-po="${po.PONumber}">
				<td><input type="radio" name="poSelect" value="${po.PONumber}" ${selectedPO && selectedPO.PONumber === po.PONumber ? "checked" : ""}></td>
				<td><span class="object-identifier-title">${po.PONumber}</span></td>
				<td>${escapeHtml(po.Entity)}</td>
				<td>${escapeHtml(po.Description)}</td>
				<td class="num">${invoiceableCoCs.length}</td>
				<td class="num">${formatCurrency(invoiceableAmount, po.Currency)}</td>
				<td>${po.ContractRef}</td>
			</tr>`;
		}).join("");

		document.querySelectorAll("#poTable tbody tr").forEach(function (row) {
			row.addEventListener("click", function () {
				selectedPO = findPO(row.dataset.po);
				selectedCoC = null;
				renderPOTable();
			});
		});
	}

	// ---------- Step 2: Select CoC ----------
	function renderCoCTable() {
		const cocs = getInvoiceableCoCsForPO(selectedPO.PONumber);
		if (cocs.length === 1 && !selectedCoC) {
			selectedCoC = cocs[0];
		}

		document.querySelector("#cocTable tbody").innerHTML = cocs.map(function (c) {
			const itemSummary = c.LineItems.length === 1 ? escapeHtml(c.LineItems[0].Description) : c.LineItems.length + " line items";
			return `<tr class="row-nav" data-coc="${c.CoCNumber}">
				<td><input type="radio" name="cocSelect" value="${c.CoCNumber}" ${selectedCoC && selectedCoC.CoCNumber === c.CoCNumber ? "checked" : ""}></td>
				<td><span class="object-identifier-title">${c.CoCNumber}</span></td>
				<td>${formatDate(c.IssueDate)}</td>
				<td>${itemSummary}</td>
				<td class="num">${formatCurrency(coCAcceptedAmount(c), selectedPO.Currency)}</td>
			</tr>`;
		}).join("");

		document.querySelectorAll("#cocTable tbody tr").forEach(function (row) {
			row.addEventListener("click", function () {
				selectedCoC = findCoC(row.dataset.coc);
				renderCoCTable();
			});
		});
	}

	// ---------- Step 3: Invoice details + auto line items ----------
	function populateStep3() {
		const vendor = findVendor(CURRENT_VENDOR_ID);
		document.getElementById("poSummaryStrip").innerHTML = `${icon("info")}PO <strong>${selectedPO.PONumber}</strong> · ${escapeHtml(selectedPO.Entity)} · Certificate <strong>${selectedCoC.CoCNumber}</strong> (issued ${formatDate(selectedCoC.IssueDate)})`;
		if (!document.getElementById("invNumber").value) {
			document.getElementById("invNumber").value = "INV-2026-" + (nextInvoiceSeq++);
		}
		document.getElementById("invCurrency").value = selectedPO.Currency;
		document.getElementById("invBillingDetails").value = [vendor.CompanyName, vendor.Address, vendor.City, vendor.Country].filter(Boolean).join(", ");
		document.getElementById("invTaxInfo").value = vendor.TaxId || "Not provided";

		const lineItems = coCLineItemsToInvoiceLineItems(selectedCoC);
		document.querySelector("#lineItemsTable tbody").innerHTML = lineItems.map(function (item) {
			return `<tr>
				<td>${escapeHtml(item.Description)}</td>
				<td class="num">${item.Quantity}</td>
				<td class="num">${formatCurrency(item.UnitPrice, selectedPO.Currency)}</td>
				<td class="num">${item.TaxPercent}%</td>
				<td class="num">${formatCurrency(lineItemTotal(item), selectedPO.Currency)}</td>
			</tr>`;
		}).join("");
		document.getElementById("lineItemsGrossTotal").textContent = formatCurrency(invoiceGrossFromLineItems(lineItems), selectedPO.Currency);
	}

	// ---------- Step 4: Attachments ----------
	function renderAttachments() {
		document.getElementById("attachmentsList").innerHTML = attachments.map(function (a, idx) {
			return `<li class="upload-list-item">
				<div class="upload-list-item-icon">${icon("paperclip")}</div>
				<div class="upload-list-item-info">
					<div class="upload-list-item-name">${escapeHtml(a.fileName)}</div>
					<div class="upload-list-item-meta">${escapeHtml(a.type)} · ${objectStatusHtml("Uploaded")}</div>
				</div>
				<button class="icon-btn remove-att-btn" data-idx="${idx}" type="button">${icon("trash")}</button>
			</li>`;
		}).join("") || `<li class="text-secondary" style="list-style:none; padding: var(--space-3) 0;">No documents uploaded yet.</li>`;

		document.querySelectorAll(".remove-att-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				attachments.splice(Number(btn.dataset.idx), 1);
				renderAttachments();
			});
		});
	}

	document.getElementById("invUploadBtn").addEventListener("click", function () {
		document.getElementById("invFileInput").click();
	});

	document.getElementById("invFileInput").addEventListener("change", function (e) {
		const file = e.target.files[0];
		if (file) {
			attachments.push({ fileName: file.name, type: document.getElementById("attachmentType").value });
			renderAttachments();
		}
		e.target.value = "";
	});

	// ---------- Step 5: Advance payment ----------
	function currentGross() {
		return invoiceGrossFromLineItems(coCLineItemsToInvoiceLineItems(selectedCoC));
	}

	function currentAdvance() {
		return Math.min(getRemainingAdvanceForPO(selectedPO.PONumber), currentGross());
	}

	function populateStep5() {
		const gross = currentGross();
		const advance = currentAdvance();

		if (advance <= 0) {
			document.getElementById("noAdvanceState").classList.remove("hidden");
			document.getElementById("advancePanelState").classList.add("hidden");
		} else {
			document.getElementById("noAdvanceState").classList.add("hidden");
			document.getElementById("advancePanelState").classList.remove("hidden");
			document.getElementById("advGross").textContent = formatCurrency(gross, selectedPO.Currency);
			document.getElementById("advPaid").textContent = "– " + formatCurrency(advance, selectedPO.Currency);
			document.getElementById("advNet").textContent = formatCurrency(gross - advance, selectedPO.Currency);
		}
	}

	// ---------- Step 6: Review ----------
	function renderReview() {
		const vendor = findVendor(CURRENT_VENDOR_ID);
		const lineItems = coCLineItemsToInvoiceLineItems(selectedCoC);
		const gross = invoiceGrossFromLineItems(lineItems);
		const advance = currentAdvance();
		const net = gross - advance;

		document.getElementById("reviewContent").innerHTML = `
			<h2 class="section-title" style="margin-top:0;">Purchase Order &amp; Certificate of Completion</h2>
			<div class="form-grid" style="margin-bottom: var(--space-5);">
				<div class="form-field"><span class="form-label">PO Number</span><span>${selectedPO.PONumber}</span></div>
				<div class="form-field"><span class="form-label">Entity</span><span>${escapeHtml(selectedPO.Entity)}</span></div>
				<div class="form-field"><span class="form-label">Certificate of Completion</span><span>${selectedCoC.CoCNumber}</span></div>
				<div class="form-field"><span class="form-label">Invoice Number</span><span>${escapeHtml(document.getElementById("invNumber").value)}</span></div>
				<div class="form-field"><span class="form-label">Invoice Date</span><span>${formatDate(document.getElementById("invDate").value)}</span></div>
				<div class="form-field"><span class="form-label">Payment Terms</span><span>${document.getElementById("invPaymentTerms").value}</span></div>
				<div class="form-field"><span class="form-label">Billed From</span><span>${escapeHtml(vendor.CompanyName)}</span></div>
			</div>

			<h2 class="section-title">Accepted Line Items</h2>
			<div class="table-scroll" style="margin-bottom: var(--space-5);">
				<table class="ui-table">
					<thead><tr><th>Description</th><th class="num">Qty</th><th class="num">Unit Price</th><th class="num">Tax %</th><th class="num">Total</th></tr></thead>
					<tbody>
						${lineItems.map(function (item) {
							return `<tr><td>${escapeHtml(item.Description)}</td><td class="num">${item.Quantity}</td><td class="num">${formatCurrency(item.UnitPrice, selectedPO.Currency)}</td><td class="num">${item.TaxPercent}%</td><td class="num">${formatCurrency(lineItemTotal(item), selectedPO.Currency)}</td></tr>`;
						}).join("")}
					</tbody>
				</table>
			</div>

			<h2 class="section-title">Attachments</h2>
			<ul class="upload-list" style="margin-bottom: var(--space-5);">
				${attachments.length ? attachments.map(function (a) {
					return `<li class="upload-list-item"><div class="upload-list-item-icon">${icon("paperclip")}</div><div class="upload-list-item-info"><div class="upload-list-item-name">${escapeHtml(a.fileName)}</div><div class="upload-list-item-meta">${escapeHtml(a.type)}</div></div></li>`;
				}).join("") : `<li class="text-secondary" style="list-style:none;">No documents attached.</li>`}
			</ul>

			<h2 class="section-title">Advance Offset &amp; Final Amount</h2>
			<div class="summary-panel">
				<div class="summary-row"><span>Invoice Amount</span><span>${formatCurrency(gross, selectedPO.Currency)}</span></div>
				<div class="summary-row"><span>Advance Already Paid</span><span>– ${formatCurrency(advance, selectedPO.Currency)}</span></div>
				<div class="summary-row total"><span>Final Payable Amount</span><span>${formatCurrency(net, selectedPO.Currency)}</span></div>
			</div>
		`;
	}

	function validateStep(step) {
		if (step === 1 && !selectedPO) {
			showToast("Please select a purchase order to continue.");
			return false;
		}
		if (step === 2 && !selectedCoC) {
			showToast("Please select a Certificate of Completion to continue.");
			return false;
		}
		if (step === 3) {
			if (!document.getElementById("invNumber").value.trim() || !document.getElementById("invDate").value) {
				showToast("Please complete the invoice number and date.");
				return false;
			}
		}
		if (step === 4) {
			const hasTaxInvoice = attachments.some(function (a) { return a.type === "Tax Invoice"; });
			if (!hasTaxInvoice) {
				showToast("Please upload the tax invoice before continuing.");
				return false;
			}
		}
		return true;
	}

	function submitInvoice(status) {
		const lineItems = coCLineItemsToInvoiceLineItems(selectedCoC);
		const vendor = findVendor(CURRENT_VENDOR_ID);
		const invoice = {
			InvoiceId: document.getElementById("invNumber").value.trim(),
			PONumber: selectedPO.PONumber,
			CoCNumber: selectedCoC.CoCNumber,
			VendorId: CURRENT_VENDOR_ID,
			VendorName: vendor.CompanyName,
			Entity: selectedPO.Entity,
			InvoiceDate: document.getElementById("invDate").value,
			DueDate: document.getElementById("invDate").value,
			Currency: selectedPO.Currency,
			PaymentTerms: document.getElementById("invPaymentTerms").value,
			AdvanceAmount: currentAdvance(),
			Status: status,
			SubmittedOn: status === "Draft" ? null : document.getElementById("invDate").value,
			LineItems: lineItems,
			Attachments: attachments.map(function (a) { return { FileName: a.fileName, DocumentType: a.type, UploadStatus: "Uploaded" }; })
		};
		INVOICES.unshift(invoice);
		return invoice;
	}

	document.getElementById("wizardNextBtn").addEventListener("click", function () {
		if (!validateStep(currentStep)) { return; }

		if (currentStep === 6) {
			const invoice = submitInvoice("Submitted");
			document.getElementById("doneTitle").textContent = "Invoice submitted successfully";
			document.getElementById("doneText").textContent = "Invoice " + invoice.InvoiceId + " has been sent for approval. You can track its progress from Invoice History.";
			showStep("done");
			return;
		}

		currentStep += 1;
		if (currentStep === 2) { renderCoCTable(); }
		if (currentStep === 3) { populateStep3(); }
		if (currentStep === 4) { renderAttachments(); }
		if (currentStep === 5) { populateStep5(); }
		if (currentStep === 6) { renderReview(); }
		showStep(currentStep);
	});

	document.getElementById("wizardBackBtn").addEventListener("click", function () {
		if (currentStep > 1) {
			currentStep -= 1;
			showStep(currentStep);
		}
	});

	document.getElementById("wizardSaveDraftBtn").addEventListener("click", function () {
		if (!selectedPO || !selectedCoC) {
			showToast("Please select a purchase order and Certificate of Completion first.");
			return;
		}
		if (!document.getElementById("invNumber").value.trim()) {
			document.getElementById("invNumber").value = "INV-2026-" + (nextInvoiceSeq++);
		}
		if (!document.getElementById("invDate").value) {
			document.getElementById("invDate").value = "2026-07-08";
		}
		const invoice = submitInvoice("Draft");
		showToast("Invoice " + invoice.InvoiceId + " saved as draft.");
		goTo("invoice-detail.html?invoiceId=" + invoice.InvoiceId);
	});

	renderPOTable();
	showStep(1);
})();
