(function () {
	let activeStatus = "All";
	let searchTerm = "";

	function render() {
		const filtered = VENDORS.filter(function (v) {
			const matchesStatus = activeStatus === "All" || v.Status === activeStatus;
			const haystack = (v.CompanyName + " " + v.ContactFirstName + " " + v.ContactLastName).toLowerCase();
			const matchesSearch = haystack.indexOf(searchTerm.toLowerCase()) !== -1;
			return matchesStatus && matchesSearch;
		}).sort(function (a, b) { return b.InvitedOn.localeCompare(a.InvitedOn); });

		const rows = filtered.map(function (v) {
			return `<tr class="row-nav" onclick="goTo('vendor-detail.html?vendorId=${v.VendorId}')">
				<td>
					<div class="object-identifier-title">${escapeHtml(v.CompanyName)}</div>
					<div class="object-identifier-subtitle">${escapeHtml(v.Email)}</div>
				</td>
				<td>${escapeHtml(v.ContactTitle)} ${escapeHtml(v.ContactFirstName)} ${escapeHtml(v.ContactLastName)}</td>
				<td>${escapeHtml(v.Country) || "–"}</td>
				<td>${objectStatusHtml(v.Status)}</td>
				<td>${objectStatusHtml(v.QualificationStatus)}</td>
				<td>${formatDate(v.InvitedOn)}</td>
			</tr>`;
		}).join("");

		document.querySelector("#vendorsTable tbody").innerHTML = rows ||
			`<tr><td colspan="6"><div class="empty-state">${icon("search")}<div>No vendors match your filters.</div></div></td></tr>`;

		document.getElementById("resultCount").textContent = filtered.length + " of " + VENDORS.length + " vendors";
	}

	document.getElementById("searchInput").addEventListener("input", function (e) {
		searchTerm = e.target.value;
		render();
	});

	document.getElementById("statusChips").addEventListener("click", function (e) {
		const btn = e.target.closest(".chip");
		if (!btn) { return; }
		document.querySelectorAll("#statusChips .chip").forEach(function (c) { c.classList.remove("active"); });
		btn.classList.add("active");
		activeStatus = btn.dataset.status;
		render();
	});

	render();
})();
