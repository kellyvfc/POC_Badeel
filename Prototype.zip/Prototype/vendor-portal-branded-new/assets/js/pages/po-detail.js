(function () {
	const poNumber = qs("poNumber") || PURCHASE_ORDERS[0].PONumber;
	const po = findPO(poNumber) || PURCHASE_ORDERS[0];
	const vendor = findVendor(po.VendorId);
	const fullyAccepted = isPOFullyAccepted(po.PONumber);

	document.title = po.PONumber + " – Badeel Vendor Portal";
	document.getElementById("breadcrumbPO").textContent = po.PONumber;
	document.getElementById("poTitle").textContent = po.PONumber;
	document.getElementById("poSubtitle").textContent = po.Entity + " · " + po.Description;
	document.getElementById("poStatusBadge").innerHTML = fullyAccepted
		? `<span class="object-status state-success">${icon("check-circle")}Fully Accepted</span>`
		: `<span class="object-status state-info">${icon("clock")}Open</span>`;

	document.getElementById("factVendor").innerHTML = `<a href="vendor-detail.html?vendorId=${po.VendorId}">${vendor ? escapeHtml(vendor.CompanyName) : po.VendorId}</a>`;
	document.getElementById("factPOValue").textContent = formatCurrency(po.POValue, po.Currency);
	document.getElementById("factAdvance").textContent = formatCurrency(po.AdvancePaid, po.Currency);
	document.getElementById("factContractRef").textContent = po.ContractRef;

	const progress = getPOLineItemProgress(po.PONumber);
	const remainingValue = progress.reduce(function (sum, li) { return sum + li.RemainingQty * li.UnitPrice; }, 0);
	document.getElementById("factRemaining").textContent = formatCurrency(remainingValue, po.Currency);

	document.querySelector("#lineItemsTable tbody").innerHTML = progress.map(function (li) {
		return `<tr>
			<td>${escapeHtml(li.Description)}</td>
			<td class="num">${li.OrderedQty}</td>
			<td class="num">${li.AcceptedQty}</td>
			<td class="num">${li.RemainingQty > 0 ? li.RemainingQty : `<span class="text-secondary">0</span>`}</td>
		</tr>`;
	}).join("");

	const requests = getCompletionRequestsForPO(po.PONumber);
	document.querySelector("#crTable tbody").innerHTML = requests.length
		? requests.map(function (r) {
			const itemSummary = r.LineItems.length === 1 ? escapeHtml(r.LineItems[0].Description) : r.LineItems.length + " line items";
			return `<tr class="row-nav" onclick="goTo('completion-request-detail.html?requestId=${r.CompletionRequestId}')">
				<td><span class="object-identifier-title">${r.CompletionRequestId}</span></td>
				<td>${itemSummary}</td>
				<td>${objectStatusHtml(r.Status)}</td>
				<td>${r.SubmittedOn ? formatDate(r.SubmittedOn) : "–"}</td>
			</tr>`;
		}).join("")
		: `<tr><td colspan="4" class="text-secondary">No completion requests submitted yet.</td></tr>`;

	const cocs = getCoCsForPO(po.PONumber);
	document.querySelector("#cocTable tbody").innerHTML = cocs.length
		? cocs.map(function (c) {
			return `<tr class="row-nav" onclick="goTo('coc-detail.html?coCNumber=${c.CoCNumber}')">
				<td><span class="object-identifier-title">${c.CoCNumber}</span></td>
				<td>${formatDate(c.IssueDate)}</td>
				<td>${objectStatusHtml(c.Status)}</td>
				<td class="num">${formatCurrency(coCAcceptedAmount(c), po.Currency)}</td>
			</tr>`;
		}).join("")
		: `<tr><td colspan="4" class="text-secondary">No certificates of completion issued yet.</td></tr>`;

	const invoices = getInvoicesForPO(po.PONumber);
	document.querySelector("#invoicesTable tbody").innerHTML = invoices.length
		? invoices.map(function (inv) {
			return `<tr class="row-nav" onclick="goTo('invoice-detail.html?invoiceId=${inv.InvoiceId}')">
				<td><span class="object-identifier-title">${inv.InvoiceId}</span></td>
				<td>${inv.CoCNumber}</td>
				<td>${objectStatusHtml(inv.Status)}</td>
				<td>${formatDate(inv.InvoiceDate)}</td>
			</tr>`;
		}).join("")
		: `<tr><td colspan="4" class="text-secondary">No invoices raised against this PO yet.</td></tr>`;

	document.getElementById("anchorBar").addEventListener("click", function (e) {
		const btn = e.target.closest("button");
		if (!btn) { return; }
		document.querySelectorAll("#anchorBar button").forEach(function (b) { b.classList.remove("active"); });
		btn.classList.add("active");
		const target = btn.dataset.section;
		document.querySelectorAll("[data-section-panel]").forEach(function (panel) {
			panel.classList.toggle("hidden", panel.dataset.sectionPanel !== target);
		});
	});
})();
