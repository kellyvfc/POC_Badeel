(function () {
	const role = getRole();
	const requestId = qs("requestId") || COMPLETION_REQUESTS[0].CompletionRequestId;
	const request = findCompletionRequest(requestId) || COMPLETION_REQUESTS[0];
	let nextCocSeq = 4001;

	function todayIso() {
		return "2026-07-08";
	}

	function render() {
		const po = findPO(request.PONumber);
		const vendor = findVendor(request.VendorId);

		document.title = request.CompletionRequestId + " – Badeel Vendor Portal";
		document.getElementById("breadcrumbRequest").textContent = request.CompletionRequestId;
		document.getElementById("reqTitle").textContent = request.CompletionRequestId;
		document.getElementById("reqSubtitle").textContent = request.PONumber + (po ? " · " + po.Description : "");
		document.getElementById("reqStatusBadge").innerHTML = objectStatusHtml(request.Status);

		document.getElementById("factPO").innerHTML = `<a href="po-detail.html?poNumber=${request.PONumber}">${request.PONumber}</a>`;
		document.getElementById("factVendor").textContent = vendor ? vendor.CompanyName : request.VendorId;
		document.getElementById("factSubmitted").textContent = request.SubmittedOn ? formatDate(request.SubmittedOn) : "Not yet submitted";
		document.getElementById("factReviewed").textContent = request.ReviewedOn ? formatDate(request.ReviewedOn) : "–";
		document.getElementById("factReviewer").textContent = request.ReviewedBy || "–";

		document.querySelector("#lineItemsTable tbody").innerHTML = request.LineItems.map(function (li) {
			return `<tr><td>${escapeHtml(li.Description)}</td><td class="num">${li.OrderedQty}</td><td class="num">${li.CompletedQty}</td></tr>`;
		}).join("");

		document.getElementById("reqComments").textContent = request.Comments || "No comments provided.";

		document.getElementById("attachmentsList").innerHTML = request.Attachments.length
			? request.Attachments.map(function (a) {
				return `<li class="upload-list-item">
					<div class="upload-list-item-icon">${icon("paperclip")}</div>
					<div class="upload-list-item-info">
						<div class="upload-list-item-name">${escapeHtml(a.FileName)}</div>
						<div class="upload-list-item-meta">${escapeHtml(a.DocumentType)}</div>
					</div>
					${objectStatusHtml(a.UploadStatus)}
				</li>`;
			}).join("")
			: `<li class="text-secondary" style="list-style:none;">No supporting evidence attached.</li>`;

		if (request.Status === "Rejected" && request.RejectionReason) {
			const strip = document.getElementById("rejectionStrip");
			strip.innerHTML = `${icon("alert-triangle")}<div><strong>Request rejected.</strong> ${escapeHtml(request.RejectionReason)}</div>`;
			strip.classList.remove("hidden");
		}

		if (request.Status === "Accepted" && request.CoCNumber) {
			const strip = document.getElementById("cocStrip");
			strip.innerHTML = `${icon("check-circle")}<div>Accepted. <a href="coc-detail.html?coCNumber=${request.CoCNumber}">View Certificate of Completion ${request.CoCNumber}</a></div>`;
			strip.classList.remove("hidden");
		}

		if (qs("justSubmitted") === "1") {
			const strip = document.getElementById("successStrip");
			strip.innerHTML = `${icon("check-circle")}Your Completion Request has been submitted for review by Badeel Procurement.`;
			strip.classList.remove("hidden");
		}

		renderActions();
	}

	function renderActions() {
		const actionsEl = document.getElementById("reqActions");
		if (role === "admin" && (request.Status === "Submitted" || request.Status === "Under Review")) {
			actionsEl.innerHTML = `
				<button class="btn btn-danger btn-sm" id="rejectBtn">Reject</button>
				<button class="btn btn-primary btn-sm" id="acceptBtn">Accept &amp; Issue CoC</button>
			`;
			document.getElementById("acceptBtn").addEventListener("click", onAccept);
			document.getElementById("rejectBtn").addEventListener("click", function () {
				document.getElementById("rejectReasonInput").value = "";
				openDialog("rejectDialog");
			});
		} else {
			actionsEl.innerHTML = "";
		}
	}

	function onAccept() {
		const po = findPO(request.PONumber);
		const cocNumber = "CoC-" + (nextCocSeq++);

		const cocLineItems = request.LineItems.map(function (reqLi) {
			const poLi = po.LineItems.find(function (l) { return l.LineItemId === reqLi.LineItemId; });
			return {
				LineItemId: reqLi.LineItemId,
				Description: reqLi.Description,
				AcceptedQty: reqLi.CompletedQty,
				UnitPrice: poLi ? poLi.UnitPrice : 0,
				TaxPercent: poLi ? poLi.TaxPercent : 0
			};
		});

		CERTIFICATES_OF_COMPLETION.unshift({
			CoCNumber: cocNumber,
			PONumber: request.PONumber,
			VendorId: request.VendorId,
			IssueDate: todayIso(),
			Status: "Approved",
			CompletionRequestId: request.CompletionRequestId,
			ApprovedBy: "Karim Haddad",
			LineItems: cocLineItems
		});

		request.Status = "Accepted";
		request.ReviewedOn = todayIso();
		request.ReviewedBy = "Karim Haddad";
		request.CoCNumber = cocNumber;

		showToast("Completion Request accepted. Certificate of Completion " + cocNumber + " issued.");
		render();
	}

	document.getElementById("confirmRejectBtn").addEventListener("click", function () {
		const reason = document.getElementById("rejectReasonInput").value.trim();
		if (!reason) {
			showToast("Please provide a reason for rejection.");
			return;
		}
		request.Status = "Rejected";
		request.ReviewedOn = todayIso();
		request.ReviewedBy = "Karim Haddad";
		request.RejectionReason = reason;
		closeDialog("rejectDialog");
		showToast("Completion Request rejected.");
		render();
	});

	render();
})();
