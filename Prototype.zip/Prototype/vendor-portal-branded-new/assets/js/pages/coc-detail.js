(function () {
	const coCNumber = qs("coCNumber") || CERTIFICATES_OF_COMPLETION[0].CoCNumber;
	const coc = findCoC(coCNumber) || CERTIFICATES_OF_COMPLETION[0];
	const po = findPO(coc.PONumber);

	document.title = coc.CoCNumber + " – Badeel Vendor Portal";
	document.getElementById("breadcrumbCoc").textContent = coc.CoCNumber;
	document.getElementById("cocTitle").textContent = coc.CoCNumber;
	document.getElementById("cocSubtitle").textContent = coc.PONumber + (po ? " · " + po.Description : "");
	document.getElementById("cocStatusBadge").innerHTML = objectStatusHtml(coc.Status);

	document.getElementById("factPO").innerHTML = `<a href="po-detail.html?poNumber=${coc.PONumber}">${coc.PONumber}</a>`;
	document.getElementById("factIssueDate").textContent = formatDate(coc.IssueDate);
	document.getElementById("factApprovedBy").textContent = coc.ApprovedBy || "–";
	document.getElementById("factAcceptedAmount").textContent = formatCurrency(coCAcceptedAmount(coc), po ? po.Currency : "EUR");

	const relatedInvoice = getInvoiceForCoC(coc.CoCNumber);
	document.getElementById("factInvoiceUsed").innerHTML = relatedInvoice
		? `<a href="invoice-detail.html?invoiceId=${relatedInvoice.InvoiceId}">${relatedInvoice.InvoiceId}</a>`
		: `<span class="text-secondary">Not yet invoiced</span>`;

	document.querySelector("#lineItemsTable tbody").innerHTML = coc.LineItems.map(function (li) {
		return `<tr>
			<td>${escapeHtml(li.Description)}</td>
			<td class="num">${li.AcceptedQty}</td>
			<td class="num">${formatCurrency(li.UnitPrice, po ? po.Currency : "EUR")}</td>
			<td class="num">${li.TaxPercent}%</td>
			<td class="num">${formatCurrency(coCLineItemTotal(li), po ? po.Currency : "EUR")}</td>
		</tr>`;
	}).join("");

	if (po) {
		document.querySelector("#remainingTable tbody").innerHTML = getPOLineItemProgress(po.PONumber).map(function (li) {
			return `<tr>
				<td>${escapeHtml(li.Description)}</td>
				<td class="num">${li.OrderedQty}</td>
				<td class="num">${li.AcceptedQty}</td>
				<td class="num">${li.RemainingQty}</td>
			</tr>`;
		}).join("");
	}

	const request = findCompletionRequest(coc.CompletionRequestId);
	if (request) {
		document.getElementById("evidenceLink").innerHTML = `Issued from <a href="completion-request-detail.html?requestId=${request.CompletionRequestId}">Completion Request ${request.CompletionRequestId}</a>, reviewed by ${escapeHtml(coc.ApprovedBy || "Badeel Procurement")}.`;
		document.getElementById("attachmentsList").innerHTML = request.Attachments.length
			? request.Attachments.map(function (a) {
				return `<li class="upload-list-item">
					<div class="upload-list-item-icon">${icon("paperclip")}</div>
					<div class="upload-list-item-info">
						<div class="upload-list-item-name">${escapeHtml(a.FileName)}</div>
						<div class="upload-list-item-meta">${escapeHtml(a.DocumentType)}</div>
					</div>
				</li>`;
			}).join("")
			: `<li class="text-secondary" style="list-style:none;">No evidence files attached.</li>`;
	}
})();
