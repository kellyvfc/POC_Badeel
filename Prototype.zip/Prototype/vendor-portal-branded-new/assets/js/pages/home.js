(function () {
	const role = getRole();

	if (role === "admin") {
		document.getElementById("welcomeTitle").textContent = "Welcome back, Karim Haddad";
		document.getElementById("welcomeSubtitle").textContent = "Here is an overview of completion acceptance and invoicing activity.";
		document.getElementById("adminSection").classList.remove("hidden");
		renderAdminHome();
	} else {
		document.getElementById("welcomeTitle").textContent = "Welcome back, Sofia Marín";
		document.getElementById("welcomeSubtitle").textContent = "Here is what is happening with your account today.";
		document.getElementById("vendorSection").classList.remove("hidden");
		renderVendorHome();
	}

	function isAwaitingReview(r) {
		return r.Status === "Submitted" || r.Status === "Under Review";
	}

	function renderAdminHome() {
		document.getElementById("kpiRequestsAwaitingReview").textContent = COMPLETION_REQUESTS.filter(isAwaitingReview).length;
		document.getElementById("kpiApprovedCoCs").textContent = CERTIFICATES_OF_COMPLETION.filter(function (c) { return c.Status === "Approved"; }).length;
		document.getElementById("kpiDraftInvoices").textContent = INVOICES.filter(function (i) { return i.Status === "Draft"; }).length;
		document.getElementById("kpiSubmittedInvoices").textContent = INVOICES.filter(function (i) { return i.Status === "Submitted"; }).length;
		document.getElementById("kpiUnderApproval").textContent = INVOICES.filter(function (i) { return i.Status === "Under Review"; }).length;
		document.getElementById("kpiPaidInvoices").textContent = INVOICES.filter(function (i) { return i.Status === "Paid"; }).length;

		const rows = COMPLETION_REQUESTS
			.filter(isAwaitingReview)
			.slice()
			.sort(function (a, b) { return (b.SubmittedOn || "").localeCompare(a.SubmittedOn || ""); })
			.slice(0, 6)
			.map(function (r) {
				const vendor = findVendor(r.VendorId);
				return `<tr class="row-nav" onclick="goTo('completion-request-detail.html?requestId=${r.CompletionRequestId}')">
					<td><span class="object-identifier-title">${r.CompletionRequestId}</span></td>
					<td>${vendor ? escapeHtml(vendor.CompanyName) : r.VendorId}</td>
					<td>${r.PONumber}</td>
					<td>${objectStatusHtml(r.Status)}</td>
					<td>${formatDate(r.SubmittedOn)}</td>
				</tr>`;
			}).join("");
		document.querySelector("#adminActivityTable tbody").innerHTML = rows || `<tr><td colspan="5" class="text-secondary">Nothing awaiting review right now.</td></tr>`;
	}

	function renderVendorHome() {
		const myRequests = getCompletionRequestsForVendor(CURRENT_VENDOR_ID);
		const myCoCs = getCoCsForVendor(CURRENT_VENDOR_ID);
		const myInvoices = getInvoicesForVendor(CURRENT_VENDOR_ID);

		document.getElementById("kpiRequestsAwaitingReview").textContent = myRequests.filter(isAwaitingReview).length;
		document.getElementById("kpiApprovedCoCs").textContent = myCoCs.filter(function (c) { return c.Status === "Approved"; }).length;
		document.getElementById("kpiDraftInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Draft"; }).length;
		document.getElementById("kpiSubmittedInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Submitted"; }).length;
		document.getElementById("kpiUnderApproval").textContent = myInvoices.filter(function (i) { return i.Status === "Under Review"; }).length;
		document.getElementById("kpiPaidInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Paid"; }).length;

		const rows = myRequests
			.slice()
			.sort(function (a, b) { return (b.SubmittedOn || "9999").localeCompare(a.SubmittedOn || "9999"); })
			.slice(0, 5)
			.map(function (r) {
				return `<tr class="row-nav" onclick="goTo('completion-request-detail.html?requestId=${r.CompletionRequestId}')">
					<td><span class="object-identifier-title">${r.CompletionRequestId}</span></td>
					<td>${r.PONumber}</td>
					<td>${objectStatusHtml(r.Status)}</td>
					<td>${r.SubmittedOn ? formatDate(r.SubmittedOn) : "–"}</td>
				</tr>`;
			}).join("");
		document.querySelector("#vendorActivityTable tbody").innerHTML = rows || `<tr><td colspan="4" class="text-secondary">No completion requests submitted yet.</td></tr>`;
	}
})();
