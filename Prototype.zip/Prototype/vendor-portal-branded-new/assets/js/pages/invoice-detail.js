(function () {
	const role = getRole();
	const invoiceId = qs("invoiceId") || INVOICES[0].InvoiceId;
	const invoice = findInvoice(invoiceId) || INVOICES[0];

	document.title = invoice.InvoiceId + " – Badeel Vendor Portal";
	document.getElementById("breadcrumbInvoice").textContent = invoice.InvoiceId;
	document.getElementById("invAvatar").textContent = invoice.Currency;
	document.getElementById("invTitle").textContent = invoice.InvoiceId;
	document.getElementById("invSubtitle").textContent = invoice.VendorName + " · " + invoice.Entity;
	document.getElementById("invStatusBadge").innerHTML = objectStatusHtml(invoice.Status);

	document.getElementById("factPO").innerHTML = `<a href="po-detail.html?poNumber=${invoice.PONumber}">${invoice.PONumber}</a>`;
	document.getElementById("factCoC").innerHTML = `<a href="coc-detail.html?coCNumber=${invoice.CoCNumber}">${invoice.CoCNumber}</a>`;
	document.getElementById("factEntity").textContent = invoice.Entity;
	document.getElementById("factDate").textContent = formatDate(invoice.InvoiceDate);
	document.getElementById("factDue").textContent = formatDate(invoice.DueDate);
	document.getElementById("factTerms").textContent = invoice.PaymentTerms;

	if (role === "admin") {
		document.getElementById("factVendor").textContent = invoice.VendorName;
	} else {
		document.getElementById("factVendorWrap").classList.add("hidden");
	}

	if (invoice.Status === "Rejected" && invoice.RejectionReason) {
		const strip = document.getElementById("rejectionStrip");
		strip.innerHTML = `${icon("alert-triangle")}<div><strong>Invoice rejected.</strong> ${escapeHtml(invoice.RejectionReason)}</div>`;
		strip.classList.remove("hidden");
	}

	const gross = invoiceGrossFromLineItems(invoice.LineItems);
	document.getElementById("ovGross").textContent = formatCurrency(gross, invoice.Currency);
	document.getElementById("ovAdvance").textContent = "– " + formatCurrency(invoice.AdvanceAmount, invoice.Currency);
	document.getElementById("ovNet").textContent = formatCurrency(gross - invoice.AdvanceAmount, invoice.Currency);

	document.querySelector("#lineItemsTable tbody").innerHTML = invoice.LineItems.map(function (item) {
		return `<tr>
			<td>${escapeHtml(item.Description)}</td>
			<td class="num">${item.Quantity}</td>
			<td class="num">${formatCurrency(item.UnitPrice, invoice.Currency)}</td>
			<td class="num">${item.TaxPercent}%</td>
			<td class="num">${formatCurrency(lineItemTotal(item), invoice.Currency)}</td>
		</tr>`;
	}).join("");

	document.getElementById("attachmentsList").innerHTML = invoice.Attachments.length
		? invoice.Attachments.map(function (a) {
			return `<li class="upload-list-item">
				<div class="upload-list-item-icon">${icon("file-text")}</div>
				<div class="upload-list-item-info">
					<div class="upload-list-item-name">${escapeHtml(a.FileName)}</div>
					<div class="upload-list-item-meta">${escapeHtml(a.DocumentType)}</div>
				</div>
				${objectStatusHtml(a.UploadStatus)}
			</li>`;
		}).join("")
		: `<li class="text-secondary" style="list-style:none;">No attachments on this invoice.</li>`;

	// Admin workflow actions: approve / reject invoices pending review
	if (role === "admin" && (invoice.Status === "Submitted" || invoice.Status === "Under Review")) {
		document.getElementById("invActions").innerHTML = `
			<button class="btn btn-danger btn-sm" id="rejectBtn">Reject</button>
			<button class="btn btn-primary btn-sm" id="approveBtn">Approve</button>
		`;
		document.getElementById("approveBtn").addEventListener("click", function () {
			invoice.Status = "Approved";
			document.getElementById("invStatusBadge").innerHTML = objectStatusHtml(invoice.Status);
			document.getElementById("invActions").innerHTML = "";
			showToast("Invoice " + invoice.InvoiceId + " approved.");
		});
		document.getElementById("rejectBtn").addEventListener("click", function () {
			invoice.Status = "Rejected";
			invoice.RejectionReason = invoice.RejectionReason || "Rejected by procurement administrator.";
			document.getElementById("invStatusBadge").innerHTML = objectStatusHtml(invoice.Status);
			document.getElementById("invActions").innerHTML = "";
			const strip = document.getElementById("rejectionStrip");
			strip.innerHTML = `${icon("alert-triangle")}<div><strong>Invoice rejected.</strong> ${escapeHtml(invoice.RejectionReason)}</div>`;
			strip.classList.remove("hidden");
			showToast("Invoice " + invoice.InvoiceId + " rejected.");
		});
	}

	document.getElementById("anchorBar").addEventListener("click", function (e) {
		const btn = e.target.closest("button");
		if (!btn) { return; }
		document.querySelectorAll("#anchorBar button").forEach(function (b) { b.classList.remove("active"); });
		btn.classList.add("active");
		const target = btn.dataset.section;
		document.querySelectorAll("[data-section-panel]").forEach(function (panel) {
			panel.classList.toggle("hidden", panel.dataset.sectionPanel !== target);
		});
	});
})();
