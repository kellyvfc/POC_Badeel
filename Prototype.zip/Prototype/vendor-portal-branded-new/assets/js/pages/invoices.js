(function () {
	const role = getRole();
	let activeStatus = "All";
	let searchTerm = "";

	if (role === "admin") {
		document.getElementById("pageSubtitle").textContent = "Review and manage invoices submitted by all vendors.";
		document.getElementById("invoicesTableHead").innerHTML = `<tr><th>Invoice</th><th>Vendor</th><th>PO Number</th><th>CoC</th><th class="num">Net Payable</th><th>Status</th><th>Date</th></tr>`;
	} else {
		document.getElementById("pageSubtitle").textContent = "Track the status of your submitted invoices.";
		document.getElementById("invoicesTableHead").innerHTML = `<tr><th>Invoice</th><th>PO Number</th><th>CoC</th><th class="num">Net Payable</th><th>Status</th><th>Date</th></tr>`;
		document.getElementById("headerActions").innerHTML = `<a class="btn btn-primary" href="create-invoice.html">Create Invoice</a>`;
	}

	function baseList() {
		return role === "admin" ? INVOICES : INVOICES.filter(function (i) { return i.VendorId === CURRENT_VENDOR_ID; });
	}

	function render() {
		const filtered = baseList().filter(function (inv) {
			const matchesStatus = activeStatus === "All" || inv.Status === activeStatus;
			const haystack = (inv.InvoiceId + " " + inv.PONumber + " " + inv.VendorName).toLowerCase();
			const matchesSearch = haystack.indexOf(searchTerm.toLowerCase()) !== -1;
			return matchesStatus && matchesSearch;
		}).sort(function (a, b) { return b.InvoiceDate.localeCompare(a.InvoiceDate); });

		const rows = filtered.map(function (inv) {
			const vendorCell = role === "admin" ? `<td>${escapeHtml(inv.VendorName)}</td>` : "";
			return `<tr class="row-nav" onclick="goTo('invoice-detail.html?invoiceId=${inv.InvoiceId}')">
				<td><span class="object-identifier-title">${inv.InvoiceId}</span></td>
				${vendorCell}
				<td>${inv.PONumber}</td>
				<td><a href="coc-detail.html?coCNumber=${inv.CoCNumber}" onclick="event.stopPropagation()">${inv.CoCNumber}</a></td>
				<td class="num">${formatCurrency(invoiceNetPayable(inv), inv.Currency)}</td>
				<td>${objectStatusHtml(inv.Status)}</td>
				<td>${formatDate(inv.InvoiceDate)}</td>
			</tr>`;
		}).join("");

		const colspan = role === "admin" ? 7 : 6;
		document.querySelector("#invoicesTable tbody").innerHTML = rows ||
			`<tr><td colspan="${colspan}"><div class="empty-state">${icon("search")}<div>No invoices match your filters.</div></div></td></tr>`;

		document.getElementById("resultCount").textContent = filtered.length + " of " + baseList().length + " invoices";
	}

	document.getElementById("searchInput").addEventListener("input", function (e) {
		searchTerm = e.target.value;
		render();
	});

	document.getElementById("statusChips").addEventListener("click", function (e) {
		const btn = e.target.closest(".chip");
		if (!btn) { return; }
		document.querySelectorAll("#statusChips .chip").forEach(function (c) { c.classList.remove("active"); });
		btn.classList.add("active");
		activeStatus = btn.dataset.status;
		render();
	});

	render();
})();
