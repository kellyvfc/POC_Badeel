(function () {
	let rowCount = 0;

	function addRow(prefillName, prefillEmail) {
		rowCount += 1;
		const idx = rowCount;
		const wrapper = document.createElement("div");
		wrapper.className = "repeatable-row";
		wrapper.dataset.rowId = idx;
		wrapper.innerHTML = `
			<div class="form-field">
				<label class="form-label">Vendor Contact Name<span class="required">*</span></label>
				<input type="text" class="input-name" placeholder="e.g. John Smith" value="${escapeHtml(prefillName || "")}">
				<span class="form-error">Please enter a contact name.</span>
			</div>
			<div class="form-field">
				<label class="form-label">Vendor Email Address<span class="required">*</span></label>
				<input type="email" class="input-email" placeholder="e.g. john@vendor.com" value="${escapeHtml(prefillEmail || "")}">
				<span class="form-error">Please enter a valid email address.</span>
			</div>
			<button class="icon-btn remove-row-btn" type="button" title="Remove vendor">${icon("trash")}</button>
		`;
		wrapper.querySelector(".remove-row-btn").addEventListener("click", function () {
			if (document.querySelectorAll("#vendorRows .repeatable-row").length > 1) {
				wrapper.remove();
			} else {
				showToast("At least one vendor is required.");
			}
		});
		document.getElementById("vendorRows").appendChild(wrapper);
	}

	function isValidEmail(email) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
	}

	function validateAndCollect() {
		const rows = document.querySelectorAll("#vendorRows .repeatable-row");
		const results = [];
		let allValid = true;

		rows.forEach(function (row) {
			const nameField = row.querySelector(".input-name");
			const emailField = row.querySelector(".input-email");
			const name = nameField.value.trim();
			const email = emailField.value.trim();

			const nameValid = name.length > 0;
			const emailValid = isValidEmail(email);

			nameField.closest(".form-field").classList.toggle("has-error", !nameValid);
			emailField.closest(".form-field").classList.toggle("has-error", !emailValid);

			if (!nameValid || !emailValid) {
				allValid = false;
			} else {
				results.push({ name: name, email: email });
			}
		});

		return allValid ? results : null;
	}

	function renderRecentInvites() {
		const rows = VENDORS
			.filter(function (v) { return v.Status === "Invitation Sent" || v.Status === "Pending Registration"; })
			.slice()
			.sort(function (a, b) { return b.InvitedOn.localeCompare(a.InvitedOn); })
			.map(function (v) {
				return `<tr class="row-nav" onclick="goTo('vendor-detail.html?vendorId=${v.VendorId}')">
					<td><span class="object-identifier-title">${escapeHtml(v.CompanyName)}</span></td>
					<td>${escapeHtml(v.ContactFirstName)} ${escapeHtml(v.ContactLastName)}</td>
					<td>${escapeHtml(v.Email)}</td>
					<td>${objectStatusHtml(v.Status)}</td>
					<td>${formatDate(v.InvitedOn)}</td>
				</tr>`;
			}).join("");
		document.querySelector("#recentInvitesTable tbody").innerHTML = rows || `<tr><td colspan="5" class="text-secondary">No invitations sent yet.</td></tr>`;
	}

	function todayIso() {
		return "2026-07-08";
	}

	document.getElementById("addVendorBtn").addEventListener("click", function () {
		addRow();
	});

	document.getElementById("clearFormBtn").addEventListener("click", function () {
		document.getElementById("vendorRows").innerHTML = "";
		rowCount = 0;
		addRow();
	});

	document.getElementById("sendInvitesBtn").addEventListener("click", function () {
		const vendorsToInvite = validateAndCollect();
		if (!vendorsToInvite) {
			showToast("Please fix the highlighted fields before sending.");
			return;
		}

		vendorsToInvite.forEach(function (entry) {
			const parts = entry.name.trim().split(" ");
			const newId = "V" + (2000 + Math.floor(Math.random() * 900));
			VENDORS.unshift({
				VendorId: newId,
				CompanyName: entry.name + " (Company TBD)",
				ContactTitle: "",
				ContactFirstName: parts[0] || entry.name,
				ContactLastName: parts.slice(1).join(" ") || "",
				Email: entry.email,
				Phone: "",
				Country: "",
				Address: "",
				City: "",
				Zip: "",
				Status: "Invitation Sent",
				QualificationStatus: "Not Started",
				InvitedOn: todayIso(),
				RegisteredOn: null,
				Categories: [],
				ShipToLocations: [],
				TaxId: "",
				BankVerified: false
			});
		});

		const strip = document.getElementById("successStrip");
		strip.innerHTML = `${icon("check-circle")}${vendorsToInvite.length} invitation${vendorsToInvite.length > 1 ? "s" : ""} sent successfully.`;
		strip.classList.remove("hidden");

		showToast("Invitations sent.");

		document.getElementById("vendorRows").innerHTML = "";
		rowCount = 0;
		addRow();

		renderRecentInvites();
	});

	document.getElementById("previewEmailBtn").addEventListener("click", function () {
		openDialog("emailPreviewDialog");
	});

	addRow();
	renderRecentInvites();
})();
