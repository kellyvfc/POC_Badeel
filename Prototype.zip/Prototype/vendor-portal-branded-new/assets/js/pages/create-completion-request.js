(function () {
	let selectedPO = null;
	let attachments = [];
	let nextCrSeq = 1017;

	function todayIso() {
		return "2026-07-08";
	}

	function eligiblePOs() {
		return PURCHASE_ORDERS.filter(function (po) {
			if (po.VendorId !== CURRENT_VENDOR_ID) { return false; }
			return getPOLineItemProgress(po.PONumber).some(function (li) { return li.RemainingQty > 0; });
		});
	}

	function populatePOSelect() {
		const select = document.getElementById("poSelect");
		eligiblePOs().forEach(function (po) {
			const opt = document.createElement("option");
			opt.value = po.PONumber;
			opt.textContent = po.PONumber + " — " + po.Description;
			select.appendChild(opt);
		});
	}

	function renderLineItems() {
		const progress = getPOLineItemProgress(selectedPO.PONumber);
		document.querySelector("#lineItemsTable tbody").innerHTML = progress.map(function (li, idx) {
			const disabled = li.RemainingQty <= 0;
			return `<tr class="${disabled ? "text-secondary" : ""}">
				<td><input type="checkbox" class="li-check" data-idx="${idx}" ${disabled ? "disabled" : ""}></td>
				<td>${escapeHtml(li.Description)}${disabled ? " <em>(fully accepted)</em>" : ""}</td>
				<td class="num">${li.OrderedQty}</td>
				<td class="num">${li.AcceptedQty}</td>
				<td class="num">${li.RemainingQty}</td>
				<td class="num"><input type="number" class="li-qty" data-idx="${idx}" min="0" max="${li.RemainingQty}" value="${li.RemainingQty}" style="text-align:right; width:6rem;" ${disabled ? "disabled" : ""}></td>
			</tr>`;
		}).join("");

		document.querySelectorAll(".li-check").forEach(function (cb) {
			cb.addEventListener("change", function () {
				const qtyInput = document.querySelector(`.li-qty[data-idx="${cb.dataset.idx}"]`);
				qtyInput.disabled = !cb.checked;
			});
		});
	}

	document.getElementById("poSelect").addEventListener("change", function (e) {
		const poNumber = e.target.value;
		if (!poNumber) {
			document.getElementById("lineItemsSection").classList.add("hidden");
			document.getElementById("detailsSection").classList.add("hidden");
			selectedPO = null;
			return;
		}
		selectedPO = findPO(poNumber);
		renderLineItems();
		document.getElementById("lineItemsSection").classList.remove("hidden");
		document.getElementById("detailsSection").classList.remove("hidden");
	});

	function renderAttachments() {
		document.getElementById("attachmentsList").innerHTML = attachments.map(function (a, idx) {
			return `<li class="upload-list-item">
				<div class="upload-list-item-icon">${icon("paperclip")}</div>
				<div class="upload-list-item-info">
					<div class="upload-list-item-name">${escapeHtml(a.fileName)}</div>
					<div class="upload-list-item-meta">${escapeHtml(a.type)}</div>
				</div>
				<button class="icon-btn remove-att-btn" data-idx="${idx}" type="button">${icon("trash")}</button>
			</li>`;
		}).join("");

		document.querySelectorAll(".remove-att-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				attachments.splice(Number(btn.dataset.idx), 1);
				renderAttachments();
			});
		});
	}

	document.getElementById("crUploadBtn").addEventListener("click", function () {
		document.getElementById("crFileInput").click();
	});

	document.getElementById("crFileInput").addEventListener("change", function (e) {
		const file = e.target.files[0];
		if (file) {
			attachments.push({ fileName: file.name, type: document.getElementById("attachmentType").value });
			renderAttachments();
		}
		e.target.value = "";
	});

	function collectSelectedLineItems() {
		const progress = getPOLineItemProgress(selectedPO.PONumber);
		const result = [];
		document.querySelectorAll(".li-check:checked").forEach(function (cb) {
			const idx = Number(cb.dataset.idx);
			const li = progress[idx];
			const qty = Number(document.querySelector(`.li-qty[data-idx="${idx}"]`).value) || 0;
			if (qty > 0) {
				result.push({ LineItemId: li.LineItemId, Description: li.Description, OrderedQty: li.OrderedQty, CompletedQty: qty });
			}
		});
		return result;
	}

	function buildRequest(status) {
		const id = "CR-" + (nextCrSeq++);
		return {
			CompletionRequestId: id,
			PONumber: selectedPO.PONumber,
			VendorId: CURRENT_VENDOR_ID,
			LineItems: collectSelectedLineItems(),
			Comments: document.getElementById("comments").value.trim(),
			Attachments: attachments.map(function (a) { return { FileName: a.fileName, DocumentType: a.type, UploadStatus: "Uploaded" }; }),
			Status: status,
			SubmittedOn: status === "Draft" ? null : todayIso(),
			ReviewedOn: null,
			ReviewedBy: null,
			RejectionReason: null,
			CoCNumber: null
		};
	}

	document.getElementById("saveDraftBtn").addEventListener("click", function () {
		if (!selectedPO) {
			showToast("Please select a purchase order first.");
			return;
		}
		const request = buildRequest("Draft");
		COMPLETION_REQUESTS.unshift(request);
		showToast("Completion request saved as draft.");
		goTo("completion-request-detail.html?requestId=" + request.CompletionRequestId);
	});

	document.getElementById("submitBtn").addEventListener("click", function () {
		if (!selectedPO) {
			showToast("Please select a purchase order first.");
			return;
		}
		const lineItems = collectSelectedLineItems();
		if (lineItems.length === 0) {
			showToast("Please select at least one completed line item.");
			return;
		}
		if (attachments.length === 0) {
			showToast("Please upload at least one piece of supporting evidence.");
			return;
		}
		const request = buildRequest("Submitted");
		COMPLETION_REQUESTS.unshift(request);
		goTo("completion-request-detail.html?requestId=" + request.CompletionRequestId + "&justSubmitted=1");
	});

	populatePOSelect();
})();
