(function () {
	const vendorId = qs("vendorId") || VENDORS[0].VendorId;
	const vendor = findVendor(vendorId) || VENDORS[0];

	document.getElementById("breadcrumbCompany").textContent = vendor.CompanyName;
	document.title = vendor.CompanyName + " – Badeel Vendor Portal";
	document.getElementById("vendorAvatar").textContent = initials(vendor.CompanyName);
	document.getElementById("vendorTitle").textContent = vendor.CompanyName;
	document.getElementById("vendorSubtitle").textContent = vendor.VendorId + " · " + (vendor.Categories[0] || "Category not yet set");
	document.getElementById("vendorStatusBadge").innerHTML = objectStatusHtml(vendor.Status);

	document.getElementById("factContact").textContent = [vendor.ContactTitle, vendor.ContactFirstName, vendor.ContactLastName].filter(Boolean).join(" ") || "–";
	document.getElementById("factCountry").textContent = vendor.Country || "–";
	document.getElementById("factInvited").textContent = formatDate(vendor.InvitedOn);
	document.getElementById("factRegistered").textContent = vendor.RegisteredOn ? formatDate(vendor.RegisteredOn) : "Not yet registered";
	document.getElementById("factQualification").textContent = vendor.QualificationStatus;

	function renderCompanyProfile() {
		document.getElementById("ovCompanyName").textContent = vendor.CompanyName;
		document.getElementById("ovTaxId").textContent = vendor.TaxId || "Not provided";
		document.getElementById("ovAddressLine").textContent = vendor.Address || "Not provided";
		document.getElementById("ovCity").textContent = vendor.City || "Not provided";
		document.getElementById("ovCountry").textContent = vendor.Country || "Not provided";
		document.getElementById("ovZip").textContent = vendor.Zip || "Not provided";
		document.getElementById("ovContactTitle").textContent = vendor.ContactTitle || "–";
		document.getElementById("ovContactFirstName").textContent = vendor.ContactFirstName || "–";
		document.getElementById("ovContactLastName").textContent = vendor.ContactLastName || "–";
		document.getElementById("ovContactEmail").textContent = vendor.Email || "–";
		document.getElementById("ovContactPhone").textContent = vendor.Phone || "Not provided";

		// keep the object page header's key facts in sync after edits
		document.getElementById("factContact").textContent = [vendor.ContactTitle, vendor.ContactFirstName, vendor.ContactLastName].filter(Boolean).join(" ") || "–";
		document.getElementById("factCountry").textContent = vendor.Country || "–";
	}
	renderCompanyProfile();

	const EDITABLE_FIELD_MAP = {
		edCompanyName: "CompanyName",
		edTaxId: "TaxId",
		edAddress: "Address",
		edCity: "City",
		edCountry: "Country",
		edZip: "Zip",
		edContactTitle: "ContactTitle",
		edContactFirstName: "ContactFirstName",
		edContactLastName: "ContactLastName",
		edContactEmail: "Email",
		edContactPhone: "Phone"
	};

	function setProfileEditMode(on) {
		document.querySelectorAll(".view-value").forEach(function (el) { el.classList.toggle("hidden", on); });
		document.querySelectorAll(".edit-value").forEach(function (el) { el.classList.toggle("hidden", !on); });
		document.getElementById("editProfileBtn").classList.toggle("hidden", on);
		document.getElementById("saveProfileBtn").classList.toggle("hidden", !on);
		document.getElementById("cancelProfileBtn").classList.toggle("hidden", !on);
	}

	document.getElementById("editProfileBtn").addEventListener("click", function () {
		Object.keys(EDITABLE_FIELD_MAP).forEach(function (inputId) {
			document.getElementById(inputId).value = vendor[EDITABLE_FIELD_MAP[inputId]] || "";
		});
		setProfileEditMode(true);
	});

	document.getElementById("cancelProfileBtn").addEventListener("click", function () {
		setProfileEditMode(false);
	});

	document.getElementById("saveProfileBtn").addEventListener("click", function () {
		if (!document.getElementById("edCompanyName").value.trim()) {
			showToast("Legal name is required.");
			return;
		}
		Object.keys(EDITABLE_FIELD_MAP).forEach(function (inputId) {
			vendor[EDITABLE_FIELD_MAP[inputId]] = document.getElementById(inputId).value.trim();
		});
		document.getElementById("vendorTitle").textContent = vendor.CompanyName;
		document.getElementById("vendorAvatar").textContent = initials(vendor.CompanyName);
		document.getElementById("breadcrumbCompany").textContent = vendor.CompanyName;
		renderCompanyProfile();
		setProfileEditMode(false);
		showToast("Vendor profile updated.");
	});

	document.getElementById("categoryTags").innerHTML = vendor.Categories.length
		? vendor.Categories.map(function (c) { return `<span class="tag">${escapeHtml(c)}</span>`; }).join("")
		: `<span class="text-secondary">No categories submitted yet.</span>`;

	document.querySelector("#locationsTable tbody").innerHTML = vendor.ShipToLocations.length
		? vendor.ShipToLocations.map(function (l) {
			return `<tr><td>${escapeHtml(l.Name)}</td><td>${escapeHtml(l.City)}</td><td>${escapeHtml(l.Country)}</td></tr>`;
		}).join("")
		: `<tr><td colspan="3" class="text-secondary">No locations submitted yet.</td></tr>`;

	document.getElementById("qualificationStatusRow").innerHTML = objectStatusHtml(vendor.QualificationStatus);
	document.getElementById("qualTaxId").textContent = vendor.TaxId || "Not provided";
	document.getElementById("qualBankVerified").innerHTML = vendor.BankVerified
		? `<span class="object-status state-success">${icon("check-circle")}Verified</span>`
		: `<span class="object-status state-none">${icon("clock")}Not verified</span>`;

	document.getElementById("anchorBar").addEventListener("click", function (e) {
		const btn = e.target.closest("button");
		if (!btn) { return; }
		document.querySelectorAll("#anchorBar button").forEach(function (b) { b.classList.remove("active"); });
		btn.classList.add("active");
		const target = btn.dataset.section;
		document.querySelectorAll("[data-section-panel]").forEach(function (panel) {
			panel.classList.toggle("hidden", panel.dataset.sectionPanel !== target);
		});
	});
})();
