(function () {
	const role = getRole();
	let activeStatus = "All";
	let searchTerm = "";

	if (role === "admin") {
		document.getElementById("pageSubtitle").textContent = "Review vendor requests for acceptance of completed work.";
		document.getElementById("requestsTableHead").innerHTML = `<tr><th>Request</th><th>Vendor</th><th>PO Number</th><th>Line Items</th><th>Status</th><th>Submitted On</th></tr>`;
	} else {
		document.getElementById("headerActions").innerHTML = `<a class="btn btn-primary" href="create-completion-request.html">New Completion Request</a>`;
		document.getElementById("requestsTableHead").innerHTML = `<tr><th>Request</th><th>PO Number</th><th>Line Items</th><th>Status</th><th>Submitted On</th></tr>`;
	}

	function baseList() {
		return role === "admin" ? COMPLETION_REQUESTS : getCompletionRequestsForVendor(CURRENT_VENDOR_ID);
	}

	function render() {
		const filtered = baseList().filter(function (r) {
			const matchesStatus = activeStatus === "All" || r.Status === activeStatus;
			const vendor = findVendor(r.VendorId);
			const haystack = (r.CompletionRequestId + " " + r.PONumber + " " + (vendor ? vendor.CompanyName : "")).toLowerCase();
			const matchesSearch = haystack.indexOf(searchTerm.toLowerCase()) !== -1;
			return matchesStatus && matchesSearch;
		}).sort(function (a, b) {
			return (b.SubmittedOn || "9999").localeCompare(a.SubmittedOn || "9999");
		});

		const rows = filtered.map(function (r) {
			const vendor = findVendor(r.VendorId);
			const vendorCell = role === "admin" ? `<td>${escapeHtml(vendor ? vendor.CompanyName : r.VendorId)}</td>` : "";
			const itemSummary = r.LineItems.length === 1
				? escapeHtml(r.LineItems[0].Description)
				: r.LineItems.length + " line items";
			return `<tr class="row-nav" onclick="goTo('completion-request-detail.html?requestId=${r.CompletionRequestId}')">
				<td><span class="object-identifier-title">${r.CompletionRequestId}</span></td>
				${vendorCell}
				<td>${r.PONumber}</td>
				<td>${itemSummary}</td>
				<td>${objectStatusHtml(r.Status)}</td>
				<td>${r.SubmittedOn ? formatDate(r.SubmittedOn) : "–"}</td>
			</tr>`;
		}).join("");

		const colspan = role === "admin" ? 6 : 5;
		document.querySelector("#requestsTable tbody").innerHTML = rows ||
			`<tr><td colspan="${colspan}"><div class="empty-state">${icon("search")}<div>No completion requests match your filters.</div></div></td></tr>`;

		document.getElementById("resultCount").textContent = filtered.length + " of " + baseList().length + " requests";
	}

	document.getElementById("searchInput").addEventListener("input", function (e) {
		searchTerm = e.target.value;
		render();
	});

	document.getElementById("statusChips").addEventListener("click", function (e) {
		const btn = e.target.closest(".chip");
		if (!btn) { return; }
		document.querySelectorAll("#statusChips .chip").forEach(function (c) { c.classList.remove("active"); });
		btn.classList.add("active");
		activeStatus = btn.dataset.status;
		render();
	});

	render();
})();
