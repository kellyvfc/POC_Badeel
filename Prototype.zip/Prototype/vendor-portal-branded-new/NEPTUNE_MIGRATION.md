# Badeel Vendor Portal — Prototype → Neptune Software Migration Guide

This prototype is plain, dependency-free HTML/CSS/JS. It intentionally uses
OpenUI5/SAP Fiori **naming conventions, layout patterns, and CSS class names**
so a developer rebuilding it in Neptune DXP (App Designer / Script Editor) can
map each block to a real control with minimal guesswork. Nothing here needs a
"redesign" — it needs to be re-expressed with Neptune/UI5 building blocks.

## How to read this prototype

- One HTML file per screen (no build step, no framework runtime).
- `assets/css/shell.css` + `assets/css/components.css` — class names mirror
  OpenUI5 control names (`.generic-tile`, `.object-status`, `.side-nav`,
  `.wizard-*`, `.object-page-*`, `.upload-*`, `.dialog-*`).
- `assets/js/data.js` — mock data shaped like plausible OData entities
  (`Vendors`, `PurchaseOrders`, `Invoices`). Replace with real Neptune
  server scripts / API calls.
- `assets/js/shell.js` — renders the persistent shell + side nav and is the
  one place that knows the full navigation model (`NAV_ITEMS`).
- `assets/js/pages/*.js` — one file per screen, all direct DOM manipulation.
  Replace with Neptune widget bindings / server script calls.

## Control mapping

| Prototype element | Class / pattern | Neptune / OpenUI5 equivalent |
|---|---|---|
| Header bar | `.shellbar` | `sap.tnt.ToolHeader` or `sap.f.ShellBar` (Neptune "Shell" building block) |
| Left navigation | `.side-nav`, `.side-nav-item` | `sap.tnt.SideNavigation` + `sap.tnt.NavigationList` |
| Role switch | `.shellbar-role-switch` | `sap.m.SegmentedButton` (bound to a session/role model) |
| KPI cards | `.generic-tile` | `sap.m.GenericTile` / `sap.f.Card` |
| Data tables | `table.ui-table` | `sap.m.Table` (`ColumnListItem`, growing/paging) |
| Status pill | `.object-status` | `sap.m.ObjectStatus` (state → `sap.ui.core.ValueState`) |
| Forms | `.form-grid`, `.form-field` | `sap.ui.layout.form.SimpleForm` / `sap.ui.layout.Grid` |
| Repeatable rows (invite vendors, categories, locations) | `.repeatable-row` | Bound `sap.m.Table`/`List` over a JSON model array with add/remove |
| Modal dialogs | `.dialog-overlay`, `.dialog-box` | `sap.m.Dialog` |
| Toasts | `.toast` | `sap.m.MessageToast` |
| Banners | `.message-strip` | `sap.m.MessageStrip` |
| File upload | `.upload-zone`, `.upload-list` | `sap.m.UploadCollection` / `sap.ui.unified.FileUploader` |
| Multi-step invoice flow | `.wizard-progress`, `.wizard-panel` | `sap.m.Wizard` + `sap.m.WizardStep` |
| Vendor / Invoice detail pages | `.object-page-header`, `.anchor-bar`, `.object-page-section` | `sap.uxap.ObjectPageLayout` (header, `ObjectPageSection`, anchor bar is built in) |
| Standalone registration/landing pages | `.auth-wrapper`, `.form-page-wrapper` | Public-facing UI5 view outside the authenticated shell, or a Neptune Launchpad "guest" page |

## Suggested Neptune build order

This mirrors the same 3-step sequence used to build this prototype:

1. **Vendor Portal shell** — Neptune App (Launchpad tile) with a Shell
   building block, side navigation bound to a role/session model, and a
   Home page with role-conditional sections (`index.html` →
   `assets/js/pages/home.js` shows exactly which counts/queries each KPI
   tile needs).
2. **Vendor Onboarding** — `invite-vendors.html`, `vendors.html`,
   `vendor-detail.html`, `registration-*.html`, `vendor-qualification.html`.
   Back these with a `Vendors` table (dictionary) and server scripts for
   "send invitation" (creates a row + sends an email) and "submit
   qualification" (updates `QualificationStatus`).
3. **Vendor Invoicing** — `create-invoice.html` (→ `sap.m.Wizard`),
   `invoices.html`, `invoice-detail.html`. Back these with `PurchaseOrders`
   and `Invoices` tables and server scripts for line-item totals, advance
   reconciliation, and the approve/reject actions already stubbed in
   `invoice-detail.js`.

## What is intentionally simulated (needs real backend logic in Neptune)

- **Auth & roles** — the Vendor/Admin toggle in the shellbar is a demo
  convenience (`localStorage`). Replace with Neptune's real session/role
  context; vendors and admins should never see the same login.
- **Data persistence** — `assets/js/data.js` is an in-memory array; nothing
  survives a page reload. Replace with Neptune tables + server scripts
  (OData-shaped mock data was chosen deliberately to make this swap
  mechanical).
- **Invitation emails** — `invite-vendors.html` only *previews* the email
  design; sending is a server-side concern (Neptune server script + SMTP/
  email connector).
- **File uploads** — files are accepted by the browser and listed by name
  only; no bytes are stored. Wire to Neptune's document/attachment API.
- **Approve/Reject workflow** — currently a client-side status flip on
  `invoice-detail.html`. In Neptune this should be a server script call,
  likely backed by the platform's Workflow engine for auditability.
