/**
 * Small framework-free helpers shared across pages.
 */

const STATUS_STATE = {
	"Registered": "success",
	"Pending Registration": "warning",
	"Invitation Sent": "info",
	"Not Started": "none",
	"In Review": "warning",
	"Approved": "success",
	"Draft": "none",
	"Submitted": "info",
	"Under Review": "warning",
	"Paid": "success",
	"Rejected": "error",
	"Uploaded": "success"
};

const STATUS_ICON = {
	"Registered": "check-circle",
	"Pending Registration": "clock",
	"Invitation Sent": "mail",
	"Not Started": "info",
	"In Review": "clock",
	"Approved": "check-circle",
	"Draft": "edit",
	"Submitted": "send",
	"Under Review": "clock",
	"Paid": "dollar-sign",
	"Rejected": "alert-circle",
	"Uploaded": "check-circle"
};

function statusState(status) {
	return STATUS_STATE[status] || "none";
}

function objectStatusHtml(status) {
	const state = statusState(status);
	const iconName = STATUS_ICON[status] || "info";
	return `<span class="object-status state-${state}">${icon(iconName)}${status}</span>`;
}

function formatCurrency(amount, currency) {
	try {
		return new Intl.NumberFormat("en-GB", { style: "currency", currency: currency || "EUR", maximumFractionDigits: 0 }).format(amount);
	} catch (e) {
		return (currency || "") + " " + Math.round(amount).toLocaleString();
	}
}

function formatDate(isoDate) {
	if (!isoDate) {
		return "–";
	}
	const d = new Date(isoDate + "T00:00:00");
	return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function qs(name) {
	return new URLSearchParams(window.location.search).get(name);
}

function getRole() {
	return localStorage.getItem("vp_role") || "vendor";
}

function setRole(role) {
	localStorage.setItem("vp_role", role);
}

function initials(name) {
	return name.split(" ").map(function (p) { return p[0]; }).join("").slice(0, 2).toUpperCase();
}

function escapeHtml(str) {
	const div = document.createElement("div");
	div.textContent = str == null ? "" : String(str);
	return div.innerHTML;
}

function showToast(message) {
	let root = document.getElementById("toast-root");
	if (!root) {
		root = document.createElement("div");
		root.id = "toast-root";
		root.className = "toast-root";
		document.body.appendChild(root);
	}
	const el = document.createElement("div");
	el.className = "toast";
	el.textContent = message;
	root.appendChild(el);
	setTimeout(function () {
		el.remove();
	}, 3000);
}

function openDialog(id) {
	const el = document.getElementById(id);
	if (el) {
		el.classList.add("open");
	}
}

function closeDialog(id) {
	const el = document.getElementById(id);
	if (el) {
		el.classList.remove("open");
	}
}

function goTo(url) {
	window.location.href = url;
}
