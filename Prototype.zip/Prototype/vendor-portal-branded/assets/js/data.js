/**
 * Client-side mock data for the prototype. In the Neptune/UI5 migration this
 * is replaced by server scripts / OData services (see NEPTUNE_MIGRATION.md) —
 * the shape of each record already mirrors a plausible OData entity.
 */
const CURRENT_VENDOR_ID = "V1004";

const VENDORS = [
	{
		VendorId: "V1001",
		CompanyName: "Atlas Engineering Ltd.",
		ContactTitle: "Mr.",
		ContactFirstName: "John",
		ContactLastName: "Smith",
		Email: "john.smith@atlaseng.com",
		Phone: "+44 20 7946 0958",
		Country: "United Kingdom",
		Address: "14 Fenwick Road",
		City: "London",
		Zip: "EC2A 3QR",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-05-02",
		RegisteredOn: "2026-05-10",
		Categories: ["Power Plant Engineering Services", "Facility Maintenance"],
		ShipToLocations: [{ Name: "London HQ", Country: "United Kingdom", City: "London" }],
		TaxId: "GB123456789",
		BankVerified: true
	},
	{
		VendorId: "V1002",
		CompanyName: "Meridian Supply Chain Co.",
		ContactTitle: "Ms.",
		ContactFirstName: "Elena",
		ContactLastName: "Papadopoulos",
		Email: "elena.p@meridiansc.com",
		Phone: "+30 210 555 0134",
		Country: "Greece",
		Address: "22 Poseidonos Ave",
		City: "Athens",
		Zip: "17455",
		Status: "Registered",
		QualificationStatus: "In Review",
		InvitedOn: "2026-05-04",
		RegisteredOn: "2026-05-12",
		Categories: ["Logistics", "Spare Parts Warehousing"],
		ShipToLocations: [{ Name: "Piraeus Distribution Center", Country: "Greece", City: "Piraeus" }],
		TaxId: "EL094501783",
		BankVerified: false
	},
	{
		VendorId: "V1003",
		CompanyName: "NovaTech Digital Solutions",
		ContactTitle: "Mr.",
		ContactFirstName: "Rahul",
		ContactLastName: "Menon",
		Email: "rahul.menon@novatechds.com",
		Phone: "+971 4 555 0192",
		Country: "United Arab Emirates",
		Address: "Building 3, Dubai Internet City",
		City: "Dubai",
		Zip: "00000",
		Status: "Pending Registration",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-06-18",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1004",
		CompanyName: "Atlas Engineering Ltd.",
		ContactTitle: "Ms.",
		ContactFirstName: "Sofia",
		ContactLastName: "Marín",
		Email: "sofia.marin@atlaseng.com",
		Phone: "+34 91 555 0147",
		Country: "Spain",
		Address: "Calle Mayor 45",
		City: "Madrid",
		Zip: "28013",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-04-20",
		RegisteredOn: "2026-04-28",
		Categories: ["Power Plant Engineering Services", "Renewable Energy O&M"],
		ShipToLocations: [
			{ Name: "Madrid Solar Depot", Country: "Spain", City: "Madrid" },
			{ Name: "Seville Field Office", Country: "Spain", City: "Seville" }
		],
		TaxId: "ESB12345674",
		BankVerified: true
	},
	{
		VendorId: "V1005",
		CompanyName: "Horizon Facilities Group",
		ContactTitle: "Mr.",
		ContactFirstName: "Marcus",
		ContactLastName: "Weber",
		Email: "marcus.weber@horizonfg.de",
		Phone: "+49 89 555 0176",
		Country: "Germany",
		Address: "Königsallee 12",
		City: "Munich",
		Zip: "80331",
		Status: "Invitation Sent",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-07-01",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1006",
		CompanyName: "Pacific Legal Advisory",
		ContactTitle: "Mrs.",
		ContactFirstName: "Grace",
		ContactLastName: "Tan",
		Email: "grace.tan@pacificlegal.sg",
		Phone: "+65 6555 0128",
		Country: "Singapore",
		Address: "1 Raffles Place",
		City: "Singapore",
		Zip: "048616",
		Status: "Registered",
		QualificationStatus: "Approved",
		InvitedOn: "2026-03-14",
		RegisteredOn: "2026-03-20",
		Categories: ["Professional & Legal Services"],
		ShipToLocations: [{ Name: "Singapore Office", Country: "Singapore", City: "Singapore" }],
		TaxId: "SG198712345K",
		BankVerified: true
	},
	{
		VendorId: "V1007",
		CompanyName: "Bright Line IT Consulting",
		ContactTitle: "Mr.",
		ContactFirstName: "Daniel",
		ContactLastName: "Okafor",
		Email: "daniel.okafor@brightlineit.com",
		Phone: "+234 1 555 0163",
		Country: "Nigeria",
		Address: "12 Adeola Odeku St",
		City: "Lagos",
		Zip: "106104",
		Status: "Pending Registration",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-06-25",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	},
	{
		VendorId: "V1008",
		CompanyName: "Stellar Marine Logistics",
		ContactTitle: "Ms.",
		ContactFirstName: "Ines",
		ContactLastName: "Duarte",
		Email: "ines.duarte@stellarmarine.pt",
		Phone: "+351 21 555 0119",
		Country: "Portugal",
		Address: "Avenida da Liberdade 200",
		City: "Lisbon",
		Zip: "1250-147",
		Status: "Invitation Sent",
		QualificationStatus: "Not Started",
		InvitedOn: "2026-07-05",
		RegisteredOn: null,
		Categories: [],
		ShipToLocations: [],
		TaxId: "",
		BankVerified: false
	}
];

const PURCHASE_ORDERS = [
	{
		PONumber: "PO-100234",
		VendorId: "V1004",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		Description: "Solar Panel Preventive Maintenance Services",
		Currency: "EUR",
		POValue: 250000,
		RemainingAmount: 150000,
		AdvancePaid: 30000,
		ContractRef: "CTR-4471"
	},
	{
		PONumber: "PO-100251",
		VendorId: "V1004",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		Description: "Inverter Replacement - NREP Solar Cluster 3",
		Currency: "EUR",
		POValue: 84000,
		RemainingAmount: 84000,
		AdvancePaid: 0,
		ContractRef: "CTR-4502"
	},
	{
		PONumber: "PO-100309",
		VendorId: "V1001",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		Description: "HVAC System Maintenance - Plant Administration Building",
		Currency: "GBP",
		POValue: 62000,
		RemainingAmount: 41500,
		AdvancePaid: 10000,
		ContractRef: "CTR-3390"
	},
	{
		PONumber: "PO-100388",
		VendorId: "V1002",
		Entity: "SEPCO - Shuaiba Expansion Project Company",
		Description: "Spare Parts Warehousing & Logistics - RO Desalination Plant",
		Currency: "EUR",
		POValue: 118500,
		RemainingAmount: 118500,
		AdvancePaid: 0,
		ContractRef: "CTR-4610"
	},
	{
		PONumber: "PO-100412",
		VendorId: "V1006",
		Entity: "Badeel - Group Legal & Compliance",
		Description: "Advisory Retainer - Cross-border M&A",
		Currency: "USD",
		POValue: 90000,
		RemainingAmount: 60000,
		AdvancePaid: 15000,
		ContractRef: "CTR-2207"
	},
	{
		PONumber: "PO-100455",
		VendorId: "V1001",
		Entity: "JWAP - Jubail Water and Power Company",
		Description: "Electrical Systems Audit - CCGT Facility",
		Currency: "GBP",
		POValue: 37500,
		RemainingAmount: 37500,
		AdvancePaid: 0,
		ContractRef: "CTR-3421"
	}
];

const INVOICES = [
	{
		InvoiceId: "INV-2026-0041",
		PONumber: "PO-100234",
		VendorId: "V1004",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		InvoiceDate: "2026-06-02",
		DueDate: "2026-07-02",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		GrossAmount: 100000,
		AdvanceAmount: 30000,
		NetPayable: 70000,
		Status: "Approved",
		SubmittedOn: "2026-06-02",
		LineItems: [
			{ Description: "Q2 Preventive Maintenance - Solar Array A", Quantity: 1, UnitPrice: 65000, TaxPercent: 10 },
			{ Description: "Replacement Parts and Labor", Quantity: 1, UnitPrice: 26000, TaxPercent: 10 }
		],
		Attachments: [
			{ FileName: "Atlas_Tax_Invoice_0041.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" },
			{ FileName: "CoC_SolarArrayA_Q2.pdf", DocumentType: "Certificate of Completion", UploadStatus: "Uploaded" }
		]
	},
	{
		InvoiceId: "INV-2026-0052",
		PONumber: "PO-100309",
		VendorId: "V1001",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		InvoiceDate: "2026-06-15",
		DueDate: "2026-07-15",
		Currency: "GBP",
		PaymentTerms: "Net 30",
		GrossAmount: 20500,
		AdvanceAmount: 5000,
		NetPayable: 15500,
		Status: "Under Review",
		SubmittedOn: "2026-06-15",
		LineItems: [{ Description: "HVAC Quarterly Service Contract", Quantity: 1, UnitPrice: 18500, TaxPercent: 8 }],
		Attachments: [{ FileName: "HVAC_Invoice_0052.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0058",
		PONumber: "PO-100412",
		VendorId: "V1006",
		VendorName: "Pacific Legal Advisory",
		Entity: "Badeel - Group Legal & Compliance",
		InvoiceDate: "2026-06-20",
		DueDate: "2026-07-20",
		Currency: "USD",
		PaymentTerms: "Net 45",
		GrossAmount: 15000,
		AdvanceAmount: 0,
		NetPayable: 15000,
		Status: "Submitted",
		SubmittedOn: "2026-06-20",
		LineItems: [{ Description: "Legal Advisory Retainer - June", Quantity: 1, UnitPrice: 15000, TaxPercent: 0 }],
		Attachments: [{ FileName: "Pacific_Legal_Invoice_June.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0063",
		PONumber: "PO-100388",
		VendorId: "V1002",
		VendorName: "Meridian Supply Chain Co.",
		Entity: "SEPCO - Shuaiba Expansion Project Company",
		InvoiceDate: "2026-06-28",
		DueDate: "2026-07-28",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		GrossAmount: 42000,
		AdvanceAmount: 0,
		NetPayable: 42000,
		Status: "Rejected",
		SubmittedOn: "2026-06-28",
		RejectionReason: "Missing signed delivery note for line item 2.",
		LineItems: [
			{ Description: "Warehousing - July Allocation", Quantity: 1, UnitPrice: 30000, TaxPercent: 24 },
			{ Description: "Inbound Freight Handling", Quantity: 1, UnitPrice: 4000, TaxPercent: 20 }
		],
		Attachments: [{ FileName: "Meridian_Invoice_0063.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	},
	{
		InvoiceId: "INV-2026-0071",
		PONumber: "PO-100234",
		VendorId: "V1004",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "Badeel - National Renewable Energy Program (NREP)",
		InvoiceDate: "2026-07-03",
		DueDate: "2026-08-02",
		Currency: "EUR",
		PaymentTerms: "Net 30",
		GrossAmount: 18500,
		AdvanceAmount: 0,
		NetPayable: 18500,
		Status: "Draft",
		SubmittedOn: null,
		LineItems: [{ Description: "Emergency Callout - Inverter Fault", Quantity: 1, UnitPrice: 18500, TaxPercent: 0 }],
		Attachments: []
	},
	{
		InvoiceId: "INV-2026-0028",
		PONumber: "PO-100309",
		VendorId: "V1001",
		VendorName: "Atlas Engineering Ltd.",
		Entity: "SWEC - Shuaiba Water and Electricity Company",
		InvoiceDate: "2026-05-10",
		DueDate: "2026-06-09",
		Currency: "GBP",
		PaymentTerms: "Net 30",
		GrossAmount: 9800,
		AdvanceAmount: 0,
		NetPayable: 9800,
		Status: "Paid",
		SubmittedOn: "2026-05-10",
		PaidOn: "2026-06-08",
		LineItems: [{ Description: "HVAC Filter Replacement Program", Quantity: 1, UnitPrice: 9800, TaxPercent: 0 }],
		Attachments: [{ FileName: "HVAC_Invoice_0028.pdf", DocumentType: "Tax Invoice", UploadStatus: "Uploaded" }]
	}
];

function findVendor(vendorId) {
	return VENDORS.find(function (v) { return v.VendorId === vendorId; });
}

function findInvoice(invoiceId) {
	return INVOICES.find(function (i) { return i.InvoiceId === invoiceId; });
}

function findPO(poNumber) {
	return PURCHASE_ORDERS.find(function (p) { return p.PONumber === poNumber; });
}

function lineItemTotal(item) {
	const net = item.Quantity * item.UnitPrice;
	return net + net * (item.TaxPercent / 100);
}

function invoiceGrossFromLineItems(lineItems) {
	return lineItems.reduce(function (sum, item) { return sum + lineItemTotal(item); }, 0);
}
