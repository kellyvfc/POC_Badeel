(function () {
	const role = getRole();

	if (role === "admin") {
		document.getElementById("welcomeTitle").textContent = "Welcome back, Karim Haddad";
		document.getElementById("welcomeSubtitle").textContent = "Here is an overview of vendor onboarding and invoicing activity.";
		document.getElementById("adminSection").classList.remove("hidden");
		renderAdminHome();
	} else {
		document.getElementById("welcomeTitle").textContent = "Welcome back, Sofia Marín";
		document.getElementById("welcomeSubtitle").textContent = "Here is what is happening with your account today.";
		document.getElementById("vendorSection").classList.remove("hidden");
		renderVendorHome();
	}

	function renderAdminHome() {
		document.getElementById("kpiVendorsInvited").textContent = VENDORS.length;
		document.getElementById("kpiPendingRegistration").textContent =
			VENDORS.filter(function (v) { return v.Status === "Pending Registration"; }).length;
		document.getElementById("kpiRegisteredVendors").textContent =
			VENDORS.filter(function (v) { return v.Status === "Registered"; }).length;
		document.getElementById("kpiPendingReview").textContent =
			INVOICES.filter(function (i) { return i.Status === "Submitted" || i.Status === "Under Review"; }).length;

		const rows = VENDORS
			.slice()
			.sort(function (a, b) { return b.InvitedOn.localeCompare(a.InvitedOn); })
			.slice(0, 5)
			.map(function (v) {
				return `<tr class="row-nav" onclick="goTo('vendor-detail.html?vendorId=${v.VendorId}')">
					<td><span class="object-identifier-title">${escapeHtml(v.CompanyName)}</span></td>
					<td>${escapeHtml(v.ContactTitle)} ${escapeHtml(v.ContactFirstName)} ${escapeHtml(v.ContactLastName)}</td>
					<td>${objectStatusHtml(v.Status)}</td>
					<td>${formatDate(v.InvitedOn)}</td>
				</tr>`;
			}).join("");
		document.querySelector("#adminActivityTable tbody").innerHTML = rows;
	}

	function renderVendorHome() {
		const myInvoices = INVOICES.filter(function (i) { return i.VendorId === CURRENT_VENDOR_ID; });
		document.getElementById("kpiDraftInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Draft"; }).length;
		document.getElementById("kpiSubmittedInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Submitted"; }).length;
		document.getElementById("kpiApprovedInvoices").textContent = myInvoices.filter(function (i) { return i.Status === "Approved"; }).length;
		document.getElementById("kpiOpenPOs").textContent = PURCHASE_ORDERS.filter(function (p) { return p.VendorId === CURRENT_VENDOR_ID && p.RemainingAmount > 0; }).length;

		const rows = myInvoices
			.slice()
			.sort(function (a, b) { return b.InvoiceDate.localeCompare(a.InvoiceDate); })
			.slice(0, 5)
			.map(function (inv) {
				return `<tr class="row-nav" onclick="goTo('invoice-detail.html?invoiceId=${inv.InvoiceId}')">
					<td><span class="object-identifier-title">${inv.InvoiceId}</span></td>
					<td>${inv.PONumber}</td>
					<td class="num">${formatCurrency(inv.NetPayable, inv.Currency)}</td>
					<td>${objectStatusHtml(inv.Status)}</td>
					<td>${formatDate(inv.InvoiceDate)}</td>
				</tr>`;
			}).join("");
		document.querySelector("#vendorActivityTable tbody").innerHTML = rows;
	}
})();
