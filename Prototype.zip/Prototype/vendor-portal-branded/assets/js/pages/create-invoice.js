(function () {
	const STEP_LABELS = ["Select PO", "Invoice Details", "Line Items", "Advance Payment", "Attachments", "Review & Submit"];
	let currentStep = 1;
	let selectedPO = null;
	let lineItems = [{ Description: "", Quantity: 1, UnitPrice: 0, TaxPercent: 0 }];
	let attachments = [];

	const myPOs = PURCHASE_ORDERS.filter(function (p) { return p.VendorId === CURRENT_VENDOR_ID; });

	function renderProgress() {
		let html = "";
		STEP_LABELS.forEach(function (label, idx) {
			const stepNum = idx + 1;
			const state = stepNum < currentStep ? "done" : (stepNum === currentStep ? "active" : "");
			html += `<div class="wizard-step-indicator ${state}">
				<div class="step-circle">${stepNum < currentStep ? icon("check-circle") : stepNum}</div>
				<div class="step-label">${label}</div>
			</div>`;
			if (stepNum < STEP_LABELS.length) {
				html += `<div class="wizard-connector ${stepNum < currentStep ? "done" : ""}"></div>`;
			}
		});
		document.getElementById("wizardProgress").innerHTML = html;
	}

	function showStep(step) {
		document.querySelectorAll(".wizard-panel").forEach(function (panel) {
			panel.classList.toggle("active", panel.dataset.step === String(step));
		});
		document.getElementById("wizardNav").style.display = step === "done" ? "none" : "flex";
		document.getElementById("wizardBackBtn").style.visibility = (step === 1) ? "hidden" : "visible";
		document.getElementById("wizardNextBtn").textContent = (step === 6) ? "Submit Invoice" : "Next";
		if (typeof step === "number") {
			renderProgress();
		}
		window.scrollTo({ top: 0, behavior: "smooth" });
	}

	// ---------- Step 1: Select PO ----------
	function renderPOTable() {
		document.querySelector("#poTable tbody").innerHTML = myPOs.map(function (po) {
			return `<tr class="row-nav" data-po="${po.PONumber}">
				<td><input type="radio" name="poSelect" value="${po.PONumber}" ${selectedPO && selectedPO.PONumber === po.PONumber ? "checked" : ""}></td>
				<td><span class="object-identifier-title">${po.PONumber}</span></td>
				<td>${escapeHtml(po.Entity)}</td>
				<td>${escapeHtml(po.Description)}</td>
				<td class="num">${formatCurrency(po.POValue, po.Currency)}</td>
				<td class="num">${formatCurrency(po.RemainingAmount, po.Currency)}</td>
				<td>${po.ContractRef}</td>
			</tr>`;
		}).join("");

		document.querySelectorAll("#poTable tbody tr").forEach(function (row) {
			row.addEventListener("click", function () {
				selectedPO = findPO(row.dataset.po);
				renderPOTable();
			});
		});
	}

	// ---------- Step 2: Invoice details ----------
	function populateStep2() {
		const vendor = findVendor(CURRENT_VENDOR_ID);
		document.getElementById("poSummaryStrip").innerHTML = `${icon("info")}PO <strong>${selectedPO.PONumber}</strong> · ${escapeHtml(selectedPO.Entity)} · Remaining ${formatCurrency(selectedPO.RemainingAmount, selectedPO.Currency)}`;
		if (!document.getElementById("invNumber").value) {
			document.getElementById("invNumber").value = "INV-2026-" + String(1000 + Math.floor(Math.random() * 8999)).slice(-4);
		}
		document.getElementById("invCurrency").value = selectedPO.Currency;
		document.getElementById("invBillingDetails").value = [vendor.CompanyName, vendor.Address, vendor.City, vendor.Country].filter(Boolean).join(", ");
		document.getElementById("invTaxInfo").value = vendor.TaxId || "Not provided";
	}

	// ---------- Step 3: Line items ----------
	function lineTotal(item) {
		const net = item.Quantity * item.UnitPrice;
		return net + net * (item.TaxPercent / 100);
	}

	function grossTotal() {
		return lineItems.reduce(function (sum, item) { return sum + lineTotal(item); }, 0);
	}

	function renderLineItems() {
		document.querySelector("#lineItemsTable tbody").innerHTML = lineItems.map(function (item, idx) {
			return `<tr>
				<td><input type="text" class="li-desc" data-idx="${idx}" value="${escapeHtml(item.Description)}" placeholder="Description of work / goods"></td>
				<td class="num"><input type="number" class="li-qty" data-idx="${idx}" value="${item.Quantity}" min="0" style="text-align:right;"></td>
				<td class="num"><input type="number" class="li-price" data-idx="${idx}" value="${item.UnitPrice}" min="0" style="text-align:right;"></td>
				<td class="num"><input type="number" class="li-tax" data-idx="${idx}" value="${item.TaxPercent}" min="0" style="text-align:right;"></td>
				<td class="num">${formatCurrency(lineTotal(item), selectedPO.Currency)}</td>
				<td><button class="icon-btn remove-li-btn" data-idx="${idx}" type="button">${icon("trash")}</button></td>
			</tr>`;
		}).join("");

		document.getElementById("lineItemsGrossTotal").textContent = formatCurrency(grossTotal(), selectedPO.Currency);

		document.querySelectorAll("#lineItemsTable input").forEach(function (input) {
			input.addEventListener("input", function () {
				const idx = Number(input.dataset.idx);
				if (input.classList.contains("li-desc")) { lineItems[idx].Description = input.value; }
				if (input.classList.contains("li-qty")) { lineItems[idx].Quantity = Number(input.value) || 0; }
				if (input.classList.contains("li-price")) { lineItems[idx].UnitPrice = Number(input.value) || 0; }
				if (input.classList.contains("li-tax")) { lineItems[idx].TaxPercent = Number(input.value) || 0; }
				renderLineItems();
			});
		});
		document.querySelectorAll(".remove-li-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				if (lineItems.length > 1) {
					lineItems.splice(Number(btn.dataset.idx), 1);
					renderLineItems();
				} else {
					showToast("At least one line item is required.");
				}
			});
		});
	}

	document.getElementById("addLineItemBtn").addEventListener("click", function () {
		lineItems.push({ Description: "", Quantity: 1, UnitPrice: 0, TaxPercent: 0 });
		renderLineItems();
	});

	// ---------- Step 4: Advance payment ----------
	function populateStep4() {
		const gross = grossTotal();
		const advance = selectedPO.AdvancePaid || 0;
		document.getElementById("advGross").textContent = formatCurrency(gross, selectedPO.Currency);
		document.getElementById("advPaid").textContent = "– " + formatCurrency(advance, selectedPO.Currency);
		document.getElementById("advNet").textContent = formatCurrency(gross - advance, selectedPO.Currency);
	}

	// ---------- Step 5: Attachments ----------
	function renderAttachments() {
		document.getElementById("attachmentsList").innerHTML = attachments.map(function (a, idx) {
			return `<li class="upload-list-item">
				<div class="upload-list-item-icon">${icon("paperclip")}</div>
				<div class="upload-list-item-info">
					<div class="upload-list-item-name">${escapeHtml(a.fileName)}</div>
					<div class="upload-list-item-meta">${escapeHtml(a.type)} · ${objectStatusHtml("Uploaded")}</div>
				</div>
				<button class="icon-btn remove-att-btn" data-idx="${idx}" type="button">${icon("trash")}</button>
			</li>`;
		}).join("") || `<li class="text-secondary" style="list-style:none; padding: var(--space-3) 0;">No documents uploaded yet.</li>`;

		document.querySelectorAll(".remove-att-btn").forEach(function (btn) {
			btn.addEventListener("click", function () {
				attachments.splice(Number(btn.dataset.idx), 1);
				renderAttachments();
			});
		});
	}

	document.getElementById("invUploadBtn").addEventListener("click", function () {
		document.getElementById("invFileInput").click();
	});

	document.getElementById("invFileInput").addEventListener("change", function (e) {
		const file = e.target.files[0];
		if (file) {
			attachments.push({ fileName: file.name, type: document.getElementById("attachmentType").value });
			renderAttachments();
		}
		e.target.value = "";
	});

	// ---------- Step 6: Review ----------
	function renderReview() {
		const vendor = findVendor(CURRENT_VENDOR_ID);
		const gross = grossTotal();
		const advance = selectedPO.AdvancePaid || 0;
		const net = gross - advance;

		document.getElementById("reviewContent").innerHTML = `
			<h2 class="section-title" style="margin-top:0;">Purchase Order</h2>
			<div class="form-grid" style="margin-bottom: var(--space-5);">
				<div class="form-field"><span class="form-label">PO Number</span><span>${selectedPO.PONumber}</span></div>
				<div class="form-field"><span class="form-label">Entity</span><span>${escapeHtml(selectedPO.Entity)}</span></div>
				<div class="form-field"><span class="form-label">Invoice Number</span><span>${escapeHtml(document.getElementById("invNumber").value)}</span></div>
				<div class="form-field"><span class="form-label">Invoice Date</span><span>${formatDate(document.getElementById("invDate").value)}</span></div>
				<div class="form-field"><span class="form-label">Payment Terms</span><span>${document.getElementById("invPaymentTerms").value}</span></div>
				<div class="form-field"><span class="form-label">Billed From</span><span>${escapeHtml(vendor.CompanyName)}</span></div>
			</div>

			<h2 class="section-title">Line Items</h2>
			<div class="table-scroll" style="margin-bottom: var(--space-5);">
				<table class="ui-table">
					<thead><tr><th>Description</th><th class="num">Qty</th><th class="num">Unit Price</th><th class="num">Tax %</th><th class="num">Total</th></tr></thead>
					<tbody>
						${lineItems.map(function (item) {
							return `<tr><td>${escapeHtml(item.Description) || "–"}</td><td class="num">${item.Quantity}</td><td class="num">${formatCurrency(item.UnitPrice, selectedPO.Currency)}</td><td class="num">${item.TaxPercent}%</td><td class="num">${formatCurrency(lineTotal(item), selectedPO.Currency)}</td></tr>`;
						}).join("")}
					</tbody>
				</table>
			</div>

			<h2 class="section-title">Attachments</h2>
			<ul class="upload-list" style="margin-bottom: var(--space-5);">
				${attachments.length ? attachments.map(function (a) {
					return `<li class="upload-list-item"><div class="upload-list-item-icon">${icon("paperclip")}</div><div class="upload-list-item-info"><div class="upload-list-item-name">${escapeHtml(a.fileName)}</div><div class="upload-list-item-meta">${escapeHtml(a.type)}</div></div></li>`;
				}).join("") : `<li class="text-secondary" style="list-style:none;">No documents attached.</li>`}
			</ul>

			<h2 class="section-title">Advance Offset &amp; Final Amount</h2>
			<div class="summary-panel">
				<div class="summary-row"><span>Gross Invoice Amount</span><span>${formatCurrency(gross, selectedPO.Currency)}</span></div>
				<div class="summary-row"><span>Advance Already Paid</span><span>– ${formatCurrency(advance, selectedPO.Currency)}</span></div>
				<div class="summary-row total"><span>Final Amount Payable</span><span>${formatCurrency(net, selectedPO.Currency)}</span></div>
			</div>
		`;
	}

	function validateStep(step) {
		if (step === 1 && !selectedPO) {
			showToast("Please select a purchase order to continue.");
			return false;
		}
		if (step === 2) {
			if (!document.getElementById("invNumber").value.trim() || !document.getElementById("invDate").value) {
				showToast("Please complete the invoice number and date.");
				return false;
			}
		}
		if (step === 3) {
			const valid = lineItems.every(function (i) { return i.Description.trim() && i.Quantity > 0 && i.UnitPrice >= 0; });
			if (!valid) {
				showToast("Each line item needs a description, quantity, and unit price.");
				return false;
			}
		}
		return true;
	}

	document.getElementById("wizardNextBtn").addEventListener("click", function () {
		if (!validateStep(currentStep)) { return; }

		if (currentStep === 6) {
			document.getElementById("doneTitle").textContent = "Invoice submitted successfully";
			document.getElementById("doneText").textContent = "Invoice " + document.getElementById("invNumber").value + " has been sent for approval. You can track its progress from the Invoices page.";
			showStep("done");
			return;
		}

		currentStep += 1;
		if (currentStep === 2) { populateStep2(); }
		if (currentStep === 3) { renderLineItems(); }
		if (currentStep === 4) { populateStep4(); }
		if (currentStep === 5) { renderAttachments(); }
		if (currentStep === 6) { renderReview(); }
		showStep(currentStep);
	});

	document.getElementById("wizardBackBtn").addEventListener("click", function () {
		if (currentStep > 1) {
			currentStep -= 1;
			showStep(currentStep);
		}
	});

	document.getElementById("wizardSaveDraftBtn").addEventListener("click", function () {
		showToast("Invoice saved as draft.");
	});

	renderPOTable();
	showStep(1);
})();
